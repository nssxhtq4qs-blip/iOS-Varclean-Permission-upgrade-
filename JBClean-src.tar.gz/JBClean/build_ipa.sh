#!/bin/bash
#
# build_ipa.sh — package SandboxKit into SandboxKit.ipa
#
# Mirrors the project's own Makefile:
#
#   FILES      = the sources listed in SandboxKit_FILES
#   FRAMEWORKS = UIKit Foundation CoreGraphics QuartzCore AVFoundation AVKit
#   CFLAGS     = -fobjc-arc [-fno-modules → effective -fmodules, see below]
#                -Wno-error=deprecated-declarations -Wno-unused-function
#                -Wno-nullability -I ./kexploit -I ./kexploit/pe
#                -I ./kexploit/TaskRop -I ./kexploit/headers
#   LDFLAGS    = -L./kexploit/lib -lgrabkernel2 -lxpf -lz
#                -Wl,-rpath,@executable_path/Frameworks
#   signing    = bare `ldid -S` on the binary and both embedded dylibs
#
# Notes on the two deliberate deviations, neither of which touches a source
# file:
#
#   -fmodules  The Makefile passes -fno-modules, but theos appends its own
#              MODULESFLAGS (-fmodules ...) after the instance flags (see
#              makefiles/targets/_common/darwin_tail.mk). The effective value
#              in the original theos build is therefore modules ENABLED. Using
#              -fno-modules directly fails on the chain's `@import Foundation;`
#              statements, so the effective setting is set explicitly here.
#
#   headers/   The published zip omits kexploit/headers/, yet offsets.m
#              includes xpf.h which pulls in Fat.h / Util.h / PatchFinder*.h /
#              arm64.h. These are pure declarations for the shipped
#              libxpf.dylib; nothing else changed.
#
set -euo pipefail

usage() {
  echo "usage: $0 [--src DIR] [--out NAME] [--app NAME] [--arch arm64|arm64e] [--plist FILE]"
  exit 1
}

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -d "$SCRIPT_DIR/src" ]; then SRC="$SCRIPT_DIR/src"; else SRC="$SCRIPT_DIR"; fi
OUTNAME="JBClean"
APP="jbclean"
MIN_IOS="15.0"
# arm64, NOT arm64e. The arm64e builds of the sibling app crashed on launch
# on this exact device (iOS 17.5 / A16) while the arm64 builds ran, so arm64
# is the architecture that has actually been verified here.
ARCH="arm64"
INFOPLIST=""

while [ $# -gt 0 ]; do
  case "$1" in
    --src) SRC="$2"; shift 2 ;;
    --out) OUTNAME="$2"; shift 2 ;;
    --app) APP="$2"; shift 2 ;;
    --arch) ARCH="$2"; shift 2 ;;
    --plist) INFOPLIST="$2"; shift 2 ;;
    *) usage ;;
  esac
done

# Default Info.plist lives next to the sources.
[ -z "$INFOPLIST" ] && INFOPLIST="$SRC/Info.plist"

case "$ARCH" in
  arm64|arm64e) ;;
  *) echo "unsupported --arch $ARCH (expected arm64 or arm64e)" >&2; exit 1 ;;
esac

TC="/opt/theos/toolchain/linux/iphone/bin"
SDK="/opt/theos/sdks/iPhoneOS16.5.sdk"
LDID="$TC/ldid"

# The real Apple linker: ld64-956.6 (cctools-port 1030.6.3, Xcode 16 era),
# built locally from source. theos ships ld64-609, whose output is what
# crashed arm64e builds on device; -B makes clang-11 find this one instead.
LDBIN="/opt/theos/toolchain/linux/iphone/bin"

BUILD="$SRC/build"
APPDIR="$BUILD/Payload/$APP.app"
# Final artifacts live outside $BUILD (which is wiped on every run) so the
# arm64e and arm64 builds can coexist as a fallback pair.
DIST="$SCRIPT_DIR/dist"
OUT="$DIST/${OUTNAME}-${ARCH}.ipa"

echo "==> clean"
rm -rf "$BUILD"
mkdir -p "$APPDIR/Frameworks"

# ── sources (SandboxKit_FILES) ──────────────────────────────────────────────
SRCS=()
while IFS= read -r f; do SRCS+=("$f"); done < <(cd "$SRC" && cat <<'LIST' | sed "s|^|$SRC/|"
main.m
FileManager.m
Exploit.m
kexploit/darksword.m
kexploit/offsets.m
kexploit/utils.m
kexploit/persistence.m
kexploit/decrypt.m
kexploit/TaskRop/RemoteCall.m
kexploit/TaskRop/thread.m
kexploit/TaskRop/vm.m
kexploit/TaskRop/pac.m
kexploit/TaskRop/exc.m
kexploit/TaskRop/findcachedataoff.m
kexploit/pe/sbx.m
kexploit/pe/vnode.m
kexploit/pe/vfs.m
kexploit/pe/apfs.m
LIST
)

# Optional extra sources (used when the injection feature is added).
if [ -d "$SRC/app" ]; then
  while IFS= read -r f; do SRCS+=("$f"); done < <(find "$SRC/app" -name '*.m' | sort)
fi

INCLUDES=(
  -I"$SRC"
  -I"$SRC/kexploit"
  -I"$SRC/kexploit/pe"
  -I"$SRC/kexploit/TaskRop"
  -I"$SRC/kexploit/headers"
  -I"$SRC/kexploit/xpc"
)
[ -d "$SRC/app" ] && INCLUDES+=(-I"$SRC/app")

CFLAGS=(
  # arm64e, NOT arm64 — RemoteCall needs to execute pacia() locally, and a
  # plain arm64 task cannot sign (§ see the ABI note below).
  #
  # ABI note (the thing that made this fail for a long time):
  #   clang-11 emits arm64e code with the FULL new-ABI instruction pattern
  #   (`blraaz`, `.quad _f@AUTH(ia,0)`), but it stamps the object header with
  #   cpusubtype 0x00000002 — i.e. ABI version 0, the old iOS 12/13 ABI.
  #   theos ld64 reads the ABI version from that byte, warns "object file ...
  #   was built with an incompatible arm64e ABI compiler", and then emits an
  #   OLD-ABI output. iOS 14+ refuses to load old-ABI arm64e, which the device
  #   reports as "此App需要开发者更新以在此iOS版本上运行".
  #   Patching every object's cpusubtype to 0x80000002 (ABI version 2) makes
  #   ld64 take the new-ABI path; the output then carries cpusubtype
  #   0x80000002 and grows the real new-ABI sections __TEXT,__auth_stubs and
  #   __DATA_CONST,__auth_got. See patch_obj_abi() below. Reference for the
  #   correct value: the chain's own libxpf.dylib / libgrabkernel2.dylib, whose
  #   arm64e slices are both 0x80000002.
  -target ${ARCH}-apple-ios${MIN_IOS}
  -isysroot "$SDK"
  -miphoneos-version-min=${MIN_IOS}
  -fobjc-arc
  -fmodules
  -Wno-error=deprecated-declarations
  -Wno-unused-function
  -Wno-nullability
  -Wno-everything
  -fobjc-abi-version=2
  # ld64 chained fixups. Without this the linker emits classic
  # LC_DYLD_INFO bind/rebase opcodes. Only theos's ld64-609 needs to be
  # asked explicitly; Apple's ld64-956 defaults to chains.
  -Wl,-fixup_chains
  -fobjc-legacy-dispatch
)

FRAMEWORKS=(
  -framework UIKit -framework Foundation -framework CoreGraphics
  -framework QuartzCore -framework AVFoundation -framework AVKit
  -framework CoreFoundation -framework Security -framework IOSurface
)

LIBS=( -L"$SRC/kexploit/lib" -lgrabkernel2 -lxpf -lz )

# ── arm64e new-ABI object patching ──────────────────────────────────────────
# clang-11 generates new-ABI arm64e code but stamps the object header with
# cpusubtype 0x00000002 (ABI version 0 = the old iOS 12/13 ABI). ld64 derives
# the link ABI from that byte and, seeing 0, warns "incompatible arm64e ABI
# compiler" and produces an old-ABI output that iOS 14+ refuses to load.
# Rewriting the byte to 0x80000002 (ABI version 2) makes ld64 emit a genuine
# new-ABI binary. mach_header cpusubtype lives at file offset 8 (4 bytes, LE).
patch_obj_abi() {
  /usr/bin/env python3 - "$1" <<'PYEOF'
import struct, sys
path = sys.argv[1]
with open(path, 'rb') as fh:
    data = bytearray(fh.read())
if len(data) < 12:
    sys.exit("not a Mach-O object: %s" % path)
magic, cputype, cpusubtype = struct.unpack_from('<III', data, 0)
if magic != 0xFEEDFACF:
    sys.exit("unexpected Mach-O magic 0x%08x in %s" % (magic, path))
if cputype != 0x0100000C or (cpusubtype & 0x00FFFFFF) != 2:
    sys.exit("not an arm64e object: %s (cputype=0x%x cpusubtype=0x%x)" % (path, cputype, cpusubtype))
if (cpusubtype >> 24) & 0xFF == 0x80:
    sys.exit(0)                      # already new ABI
struct.pack_into('<I', data, 8, 0x80000002)
with open(path, 'wb') as fh:
    fh.write(data)
PYEOF
}

# ── arm64e chained-fixups pointer-format repair ─────────────────────────────
# theos's ld64 encodes arm64e fixup chains with a stride of 8 bytes (its own
# consistency check is `next * 8 == delta`) but stamps the segment header with
# pointer_format 1 = DYLD_CHAINED_PTR_ARM64E, which dyld walks with a stride of
# 4. Every chain after the first pointer is therefore read at the wrong offset,
# dyld binds garbage, and the app dies during launch with no crash log written
# by our own code.
#
# Apple's toolchain uses 12 = DYLD_CHAINED_PTR_ARM64E_USERLAND24 for arm64e
# userland — verified against this device's own working arm64e binaries
# (lara.app/lara and both fat slices of libxpf.dylib / libgrabkernel2.dylib are
# all 12). Rewriting the field to 12 makes the declared stride match the
# encoded one.
#
# The rewrite is bit-exact: the only layout difference between the two formats
# is that `bind.ordinal` widens from 16 to 24 bits while `bind.zero` narrows
# from 16 to 8 (same for auth_bind). With fewer than 65536 imports every
# pointer keeps the same bit pattern under both formats.
patch_chained_pointer_format() {
  /usr/bin/env python3 - "$1" <<'PYEOF'
import struct, sys

WANT = 12          # DYLD_CHAINED_PTR_ARM64E_USERLAND24
OLD  = 1           # DYLD_CHAINED_PTR_ARM64E (stride 4 — does not match ld64)

path = sys.argv[1]
with open(path, 'rb') as fh:
    data = bytearray(fh.read())

magic, cputype, cpusubtype = struct.unpack_from('<III', data, 0)
if magic != 0xFEEDFACF or cputype != 0x0100000C:
    sys.exit("%s: not a 64-bit arm64 Mach-O" % path)

ncmds = struct.unpack_from('<I', data, 16)[0]
off = 32
fixups = None
for _ in range(ncmds):
    cmd, size = struct.unpack_from('<II', data, off)
    if cmd == 0x80000034:                       # LC_DYLD_CHAINED_FIXUPS
        fixups = struct.unpack_from('<II', data, off + 8)
    off += size

if fixups is None:
    print("    no chained fixups (nothing to patch)")
    sys.exit(0)

base, _ = fixups
version, starts_off, imports_off, symbols_off, imports_count, ifmt, sfmt = \
    struct.unpack_from('<IIIIIII', data, base)
starts = base + starts_off
seg_count = struct.unpack_from('<I', data, starts)[0]

patched = 0
formats = []
for i in range(seg_count):
    seg_off = struct.unpack_from('<I', data, starts + 4 + i * 4)[0]
    if seg_off == 0:
        continue                                # segment has no fixups
    seg = starts + seg_off
    page_size, fmt = struct.unpack_from('<HH', data, seg + 4)
    formats.append(fmt)
    if fmt == OLD:
        struct.pack_into('<H', data, seg + 6, WANT)
        patched += 1

if patched == 0:
    print("    pointer_format already %s (no change)" % (formats or "n/a"))
    sys.exit(0)

with open(path, 'wb') as fh:
    fh.write(data)
print("    pointer_format 1 -> 12 on %d segment(s) (imports=%d, encodings identical)"
      % (patched, imports_count))
PYEOF
}

# ── compile ─────────────────────────────────────────────────────────────────
echo "==> compile (${#SRCS[@]} files)"
OBJDIR="$BUILD/obj"; mkdir -p "$OBJDIR"
OBJS=()
for s in "${SRCS[@]}"; do
  o="$OBJDIR/$(echo "${s#$SRC/}" | tr '/' '_' | sed 's/\.m$/.o/')"
  printf '    CC %s\n' "$(basename "$o")"
  "$TC/clang-11" "${CFLAGS[@]}" "${INCLUDES[@]}" -c "$s" -o "$o"
  if [ "$ARCH" = "arm64e" ]; then
    patch_obj_abi "$o" || { echo "    !! ABI patch failed for $o" >&2; exit 1; }
  fi
  OBJS+=("$o")
done

# ── link ────────────────────────────────────────────────────────────────────
echo "==> link"
"$TC/clang-11" "${CFLAGS[@]}" "${OBJS[@]}" "${FRAMEWORKS[@]}" "${LIBS[@]}" -B"$LDBIN" \
  -Wl,-rpath,@executable_path/Frameworks \
  -o "$APPDIR/$APP"
file "$APPDIR/$APP"

if [ "$ARCH" = "arm64e" ]; then
  patch_chained_pointer_format "$APPDIR/$APP"
fi

# ── assert the produced architecture/ABI ────────────────────────────────────
# This is the check that would have caught the "此App需要开发者更新以在此iOS版本上
# 运行" regression: an arm64e binary with ABI byte 0 is the old iOS 12/13 ABI
# and iOS 14+ refuses to load it.
/usr/bin/env python3 - "$APPDIR/$APP" "$ARCH" <<'PYEOF'
import struct, sys
path, want = sys.argv[1], sys.argv[2]
with open(path, 'rb') as fh:
    magic, cputype, cpusubtype = struct.unpack('<III', fh.read(12))
with open(path, 'rb') as fh:
    data = fh.read()
abi = (cpusubtype >> 24) & 0xFF
ok = (magic == 0xFEEDFACF and cputype == 0x0100000C)
if want == 'arm64e':
    ok = ok and (cpusubtype & 0x00FFFFFF) == 2 and abi == 0x80
else:
    ok = ok and cpusubtype == 0
if not ok:
    sys.exit("ABI assertion FAILED: want %s, got cputype=0x%x cpusubtype=0x%08x"
             % (want, cputype, cpusubtype))
print("    ABI OK: %s (cputype=0x%x cpusubtype=0x%08x)" % (want, cputype, cpusubtype))

# For arm64e also assert the chained-fixup pointer format, because a format
# whose stride disagrees with the encoder still links cleanly and only fails
# at launch (see patch_chained_pointer_format above).
if want == 'arm64e':
    ncmds = struct.unpack_from('<I', data, 16)[0]
    off = 32
    fixups = None
    for _ in range(ncmds):
        cmd, size = struct.unpack_from('<II', data, off)
        if cmd == 0x80000034:
            fixups = struct.unpack_from('<II', data, off + 8)
        off += size
    if fixups is None:
        sys.exit("pointer-format assertion FAILED: arm64e binary has no chained fixups")
    base = fixups[0]
    starts = base + struct.unpack_from('<I', data, base + 4)[0]
    seg_count = struct.unpack_from('<I', data, starts)[0]
    formats = []
    for i in range(seg_count):
        seg_off = struct.unpack_from('<I', data, starts + 4 + i * 4)[0]
        if seg_off:
            formats.append(struct.unpack_from('<H', data, starts + seg_off + 6)[0])
    if any(f != 12 for f in formats):
        sys.exit("pointer-format assertion FAILED: want 12 everywhere, got %s" % formats)
    print("    pointer format OK: %s (DYLD_CHAINED_PTR_ARM64E_USERLAND24)" % formats)
PYEOF

# ── bundle ──────────────────────────────────────────────────────────────────
echo "==> bundle"
# Localizations: every <lang>.lproj goes into the bundle so the app follows
# the device language.
if [ -d "$SRC/locales" ]; then
  for d in "$SRC"/locales/*.lproj; do
    [ -d "$d" ] || continue
    cp -R "$d" "$APPDIR/"
    echo "    locale $(basename "$d")"
  done
fi

cp "$INFOPLIST"                   "$APPDIR/Info.plist"
cp "$SRC/LaunchScreen.storyboard" "$APPDIR/LaunchScreen.storyboard"
printf 'APPL????'                > "$APPDIR/PkgInfo"

# ── localization assertion ──────────────────────────────────────────────────
# A key the sources look up but the bundle does not carry does not fail loudly:
# NSLocalizedString returns the key, so the UI renders "tui.menu.repair". That
# is how a broken build shipped once, so it is checked here.
/usr/bin/env python3 - "$SRC" "$APPDIR/en.lproj/Localizable.strings" <<'PYEOF'
import re, sys, os, glob
src, bundle = sys.argv[1], sys.argv[2]

used = set()
for p in glob.glob(os.path.join(src, '*.m')) + glob.glob(os.path.join(src, 'app', '*.m')):
    t = open(p, encoding='utf-8').read()
    used |= set(re.findall(r'JBLoc\(@"([^"]+)"\)', t))
    used |= set(re.findall(r'JBLoc\([^)]*?@"([^"]+)"', t))
    used |= set(re.findall(r'@\[ @"(jb\.[A-Za-z0-9_.]+)"', t))

if not os.path.exists(bundle):
    sys.exit("localization assertion FAILED: %s not found" % bundle)

keys = set(re.findall(r'^"([^"]+)"\s*=', open(bundle, encoding='utf-8').read(), re.M))
missing = sorted(k for k in used if k not in keys)
if missing:
    sys.exit("localization assertion FAILED: %d key(s) referenced but not bundled:\n  %s"
             % (len(missing), "\n  ".join(missing)))
print("    localization OK: %d keys referenced, all present in the bundle" % len(used))
PYEOF

cp "$SRC/kexploit/lib/libgrabkernel2.dylib" "$APPDIR/Frameworks/"
cp "$SRC/kexploit/lib/libxpf.dylib"         "$APPDIR/Frameworks/"
chmod +x "$APPDIR/Frameworks/"*.dylib

# ── assert the bundled dylibs' chained-fixup pointer format ─────────────────
# libgrabkernel2.dylib shipped with its arm64e slice stamped pointer_format 1
# (stride 4) while its chains were encoded with stride 8, so dyld could only
# resolve 4 of its 321 pointers and the app died during load. Fail the build
# instead of shipping that again.
/usr/bin/env python3 - "$APPDIR/Frameworks" <<'PYEOF'
import struct, sys, os, glob
bad = []
for path in sorted(glob.glob(os.path.join(sys.argv[1], "*.dylib"))):
    d = open(path, 'rb').read()
    if struct.unpack_from('>I', d, 0)[0] != 0xCAFEBABE:
        slices = [(0, len(d), 'thin')]
    else:
        n = struct.unpack_from('>I', d, 4)[0]
        slices = []
        for i in range(n):
            ct, cs, o, sz, al = struct.unpack_from('>IIIII', d, 8 + i*20)
            slices.append((o, sz, 'arm64e' if (cs & 0xFFFFFF) == 2 else 'arm64'))
    for off, size, tag in slices:
        s = d[off:off+size]
        if len(s) < 32 or struct.unpack_from('<I', s, 0)[0] != 0xFEEDFACF:
            continue
        n = struct.unpack_from('<I', s, 16)[0]; o = 32; fx = None
        for _ in range(n):
            c, z = struct.unpack_from('<II', s, o)
            if c == 0x80000034: fx = struct.unpack_from('<II', s, o + 8)
            o += z
        fmts = []
        if fx:
            b = fx[0] + struct.unpack_from('<I', s, fx[0] + 4)[0]
            sc = struct.unpack_from('<I', s, b)[0]
            for j in range(sc):
                so = struct.unpack_from('<I', s, b + 4 + j*4)[0]
                if so: fmts.append(struct.unpack_from('<H', s, b + so + 6)[0])
        want = 12 if tag == 'arm64e' else None
        if tag == 'arm64e' and any(f != 12 for f in fmts):
            bad.append("%s(%s): pointer_format %s, want 12" % (os.path.basename(path), tag, fmts))
        else:
            print("    dylib OK: %-22s %-7s pointer_format=%s" % (os.path.basename(path), tag, fmts))
if bad:
    sys.exit("dylib pointer-format assertion FAILED:\n  " + "\n  ".join(bad))
PYEOF

for lib in libgrabkernel2.dylib libxpf.dylib; do
  "$TC/llvm-install-name-tool" -id "@rpath/$lib" "$APPDIR/Frameworks/$lib" 2>/dev/null || true
  "$TC/llvm-install-name-tool" -change "@executable_path/Frameworks/$lib" \
      "@rpath/$lib" "$APPDIR/$APP" 2>/dev/null || true
done

# ── sign: bare ldid -S, no entitlements (as upstream) ───────────────────────
echo "==> sign"
"$LDID" -S "$APPDIR/Frameworks/libgrabkernel2.dylib" 2>/dev/null || true
"$LDID" -S "$APPDIR/Frameworks/libxpf.dylib"         2>/dev/null || true
"$LDID" -S "$APPDIR/$APP"                            2>/dev/null || true

# ── package ─────────────────────────────────────────────────────────────────
echo "==> package"
mkdir -p "$DIST"
cd "$BUILD"
rm -f "$OUT"
zip -qry "$OUT" Payload

echo
unzip -l "$OUT"
echo
ls -lh "$OUT"
sha256sum "$OUT"
