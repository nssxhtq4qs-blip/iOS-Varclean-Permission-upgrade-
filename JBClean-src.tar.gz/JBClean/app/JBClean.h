//
//  JBClean.h
//  JBClean
//
//  Survey and remove the persistence tree a jailbreak tool planted outside the
//  app sandbox — /var/jb and the launchd job that keeps it alive.
//
//  WHY THIS NEEDS THE KERNEL PRIMITIVE
//  -----------------------------------
//  The tree is created by a process that is already root, so every directory in
//  it is root:wheel and the app (uid 501) has no write bit on them. Removing a
//  directory entry is governed by the PARENT directory's write permission, so
//  `rm -rf` fails at the first level however the app is arranged, and `chown`
//  fails too because changing an owner is a privileged operation.
//
//  Both of those checks live in the filesystem, not in the sandbox, so escaping
//  the sandbox is not enough. What does work is what FilzaJailedDS does: rewrite
//  the uid/gid stored in the APFS fsnode, in kernel memory, through the kernel
//  read/write primitive. apfs_fsnode lives in an ordinary writable zone, so that
//  write lands. No root is required, and none is used.
//
//  Once each directory is ours, unlink()/rmdir() succeed through the ordinary
//  path, and the tree can be removed.
//

#ifndef JBClean_h
#define JBClean_h

#import <Foundation/Foundation.h>
#import <sys/types.h>

NS_ASSUME_NONNULL_BEGIN

/// Every user-facing string this tool produces goes through here, so the whole
/// interface follows the system language via <lang>.lproj/Localizable.strings.
#define JBLoc(key)  NSLocalizedString((key), nil)

/// Progress callback. Invoked on whatever queue the work is running on.
typedef void (^JBProgressBlock)(NSString *line);

@interface JBClean : NSObject

/// Read-only survey of `root`. Performs no kernel writes and deletes nothing.
/// Reports existence, ownership, size, depth, the launchd plists inside it, and
/// whether each directory is openable (i.e. whether the clean can reach it).
+ (NSString *)diagnose:(NSString *)root;

/// Remove `root` and everything beneath it.
///
/// Order: unload the launchd job, take ownership of every directory through the
/// kernel, delete bottom-up, then make the parent writable just long enough to
/// rmdir `root` and restore the parent's original owner. The parent restore runs
/// even on failure.
+ (NSString *)clean:(NSString *)root progress:(JBProgressBlock)progress;

/// Facts about this process, the kernel primitive, and what the toolchain that
/// created the tree can and cannot do. No writes.
+ (NSString *)selfCheck;

/// "501:501 drwxr-xr-x" for a path, or a short reason it could not be read.
+ (NSString *)describePath:(NSString *)path;

/// Read-only description of a SYMLINK itself. lstat-based, so it reports the
/// link's own owner rather than the target's — which is exactly the distinction
/// that matters for /var, whose link and whose directory have different owners.
+ (NSString *)describeLink:(NSString *)path;

/// Hand /private/var to mobile (501:501), or give it back to root:wheel (0:0).
///
/// While it is 501:501 the app can create and remove entries directly in /var
/// with ordinary tools — which is the point. The intent is persisted, because
/// the automatic safety sweep in repairParentOwnership() otherwise treats any
/// 501:501 system directory as an interrupted clean and reverts it on the next
/// exploit run.
+ (NSString *)giveVarToMobile:(BOOL)enable;

/// Is /private/var currently deliberately owned by mobile?
+ (BOOL)varIsGivenToMobile;

/// Undo an interrupted parent-directory ownership change.
///
/// Removing the root entry requires write permission on its parent, so the
/// parent is temporarily chowned to 501:501. If the process is killed inside
/// that window the parent is left that way. The intended restore is therefore
/// recorded in NSUserDefaults *before* the change and cleared after it, and this
/// method replays any record that is still outstanding.
///
/// Returns nil when there is nothing to undo. Only ever restores a path to the
/// exact uid:gid that was recorded, so it can never "fix" something it did not
/// break.
+ (nullable NSString *)repairParentOwnership;

@end

NS_ASSUME_NONNULL_END

#endif /* JBClean_h */
