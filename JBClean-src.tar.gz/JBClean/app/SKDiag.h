//
//  SKDiag.h
//  Blade
//
//  Post-exploit diagnostics bridge.
//
//  Blade cannot show us its own crash reports from the device shell (the SSH
//  session lands in iSH, which cannot see the iOS filesystem). Fliza's App
//  Group however is bind-mounted into iSH at /root/fliza, so anything this
//  code copies there is readable from the host over SSH.
//
//  Call SKDumpToShared() once the sandbox escape has been applied.
//

#ifndef SKDiag_h
#define SKDiag_h

#import <Foundation/Foundation.h>

// Directory the host can read back. nil when no bridge is available.
NSString *SKSharedDir(void);

// Copies recent crash reports + our own sk.log into SKSharedDir() and returns a
// human-readable report of what happened.
NSString *SKDumpToShared(void);

#endif /* SKDiag_h */
