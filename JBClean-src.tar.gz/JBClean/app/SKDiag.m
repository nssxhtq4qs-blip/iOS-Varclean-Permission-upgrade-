//
//  SKDiag.m
//  Blade
//

#import "SKDiag.h"
#import "SKLog.h"

#include <unistd.h>

// Fliza's File Provider Storage, as bind-mounted into iSH at /root/fliza.
static NSString *const kKnownSharedDir =
    @"/private/var/mobile/Containers/Shared/AppGroup/"
    @"B88980C0-7C8D-4684-AA71-F2D94BDFF7F4/File Provider Storage";

static NSString *const kAppGroupBase =
    @"/private/var/mobile/Containers/Shared/AppGroup";

NSString *SKSharedDir(void) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableArray<NSString *> *cands = [NSMutableArray array];

    if (kKnownSharedDir) [cands addObject:kKnownSharedDir];

    // Fall back to any other app group that exposes a File Provider Storage —
    // the UUID changes if Fliza is reinstalled.
    for (NSString *e in [fm contentsOfDirectoryAtPath:kAppGroupBase error:NULL]) {
        NSString *p = [[kAppGroupBase stringByAppendingPathComponent:e]
                          stringByAppendingPathComponent:@"File Provider Storage"];
        BOOL isDir = NO;
        if ([fm fileExistsAtPath:p isDirectory:&isDir] && isDir) [cands addObject:p];
    }

    for (NSString *p in cands) {
        if (access(p.fileSystemRepresentation, W_OK) == 0) return p;
    }
    return cands.firstObject;
}

static NSArray<NSString *> *skCrashDirs(void) {
    return @[
        @"/var/mobile/Library/Logs/CrashReporter",
        @"/private/var/mobile/Library/Logs/CrashReporter",
        @"/var/mobile/Library/Logs/CrashReporter/DiagnosticLogs",
        @"/private/var/mobile/Library/Logs/CrashReporter/DiagnosticLogs",
        @"/var/mobile/Library/Logs/CrashReporter/DiagnosticLogs/sysdiagnose",
        @"/private/var/mobile/Library/Logs/CrashReporter/DiagnosticLogs/sysdiagnose",
        // Kernel panics. These are the ones that matter for the memory-scan
        // crashes: the panic log carries the backtrace with kernel IPs, which
        // symbolicate straight against the kernelcache.
        @"/var/mobile/Library/Logs/CrashReporter/Panics",
        @"/private/var/mobile/Library/Logs/CrashReporter/Panics",
        @"/var/logs",
        @"/private/var/logs",
        @"/var/logs/CrashReporter",
        @"/private/var/logs/CrashReporter",
        @"/var/logs/Panics",
        @"/private/var/logs/Panics",
        @"/private/var/db/PanicReporter",
    ];
}

// Newest-first list of crash reports matching the app, plus the newest few
// reports of any process (a launch failure is often logged under the
// installer or runningboard rather than under blade).
static NSArray<NSString *> *skFindCrashReports(void) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableArray<NSString *> *all = [NSMutableArray array];

    for (NSString *dir in skCrashDirs()) {
        BOOL isDir = NO;
        if (![fm fileExistsAtPath:dir isDirectory:&isDir] || !isDir) continue;
        NSArray<NSString *> *names = [fm contentsOfDirectoryAtPath:dir error:NULL];
        for (NSString *n in names) {
            NSString *lower = n.lowercaseString;
            BOOL looksRight =
                [n.pathExtension.lowercaseString isEqualToString:@"ips"] ||
                [n.pathExtension.lowercaseString isEqualToString:@"crash"] ||
                [n.pathExtension.lowercaseString isEqualToString:@"panic"] ||
                [lower hasPrefix:@"panic"] ||
                [lower containsString:@"panic-full"];
            if (!looksRight) continue;
            [all addObject:[dir stringByAppendingPathComponent:n]];
        }
    }

    [all sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
        NSDate *da = [fm attributesOfItemAtPath:a error:NULL].fileModificationDate;
        NSDate *db = [fm attributesOfItemAtPath:b error:NULL].fileModificationDate;
        return [db compare:da];           // newest first
    }];

    NSMutableArray<NSString *> *picked = [NSMutableArray array];
    // Kernel panics first — they carry the backtrace we need.
    for (NSString *p in all) {
        if ([p.lastPathComponent.lowercaseString containsString:@"panic"]) [picked addObject:p];
    }
    // Then anything mentioning blade.
    for (NSString *p in all) {
        if ([p.lastPathComponent.lowercaseString containsString:@"blade"] &&
            ![picked containsObject:p]) [picked addObject:p];
    }
    // Then a few recent ones in case the crash landed under another process name.
    for (NSString *p in all) {
        if (picked.count >= 12) break;
        if (![picked containsObject:p]) [picked addObject:p];
    }
    return picked;
}

static BOOL skCopy(NSString *src, NSString *dstDir, NSMutableString *report) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *dst = [dstDir stringByAppendingPathComponent:src.lastPathComponent];
    [fm removeItemAtPath:dst error:NULL];
    NSError *err = nil;
    if ([fm copyItemAtPath:src toPath:dst error:&err]) {
        [report appendFormat:@"  copied %@ -> %@\n", src, dst.lastPathComponent];
        return YES;
    }
    [report appendFormat:@"  FAILED %@: %@\n", src, err.localizedDescription ?: @"?"];
    return NO;
}

NSString *SKDumpToShared(void) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableString *report = [NSMutableString string];

    NSString *dst = SKSharedDir();
    [report appendFormat:@"shared dir: %@\n", dst ?: @"(none)"];
    if (!dst) return report;

    // 1. Our own application log.
    NSString *ownLog = SKLogPath();
    if (ownLog.length && [fm fileExistsAtPath:ownLog]) {
        skCopy(ownLog, dst, report);
    } else {
        [report appendFormat:@"  own log missing: %@\n", ownLog ?: @"?"];
    }

    // 2. Crash reports.
    NSArray<NSString *> *crashes = skFindCrashReports();
    [report appendFormat:@"crash reports found: %lu\n", (unsigned long)crashes.count];

    NSMutableArray<NSString *> *names = [NSMutableArray array];
    NSUInteger copied = 0;
    for (NSString *c in crashes) {
        if (copied >= 20) break;
        BOOL interesting = [c.lastPathComponent.lowercaseString containsString:@"blade"];
        if (!interesting && copied >= 4) break;      // only a few generic ones
        if (skCopy(c, dst, report)) copied++;
        [names addObject:c.lastPathComponent];
    }

    // 3. A manifest the host reads first.
    [report appendFormat:@"copied count: %lu\n", (unsigned long)copied];
    NSString *manifest = [report copy];
    [manifest writeToFile:[dst stringByAppendingPathComponent:@"blade-diag.txt"]
               atomically:YES encoding:NSUTF8StringEncoding error:NULL];

    SKLog(@"diag: dumped to %@ (%lu crash reports)", dst, (unsigned long)copied);
    return report;
}
