//
//  SKSandboxKeeper.m
//  SandboxKit — keep the sandbox escape's write permission alive
//
//  This implements the persistence design the user specified:
//
//    * After the escape, run a periodic background task.
//    * Every few seconds, probe whether write access is still present by
//      creating and writing a file on a system-privileged path.
//    * Success  -> do nothing.
//    * Failure  -> the kernel re-derived the policy from the on-disk profile;
//                  re-apply the sandbox policy edit using the kernel R/W
//                  primitive we already hold.
//
//  Invariants from that design, all of which matter:
//
//    * The periodic task ONLY re-writes the sandbox policy. It never re-runs
//      the exploit chain — re-exploiting risks a kernel panic, a plain memory
//      write does not.
//    * The probe must be on a privileged path, never inside our own container
//      (which is writable anyway and would prove nothing).
//    * sbx_escape() re-reads proc -> proc_ro -> ucred -> cr_label -> sandbox ->
//      ext_set from the kernel on every call. Nothing may be cached across
//      ticks, because the kernel can rebuild those structures at runtime.
//    * The re-apply must be idempotent so repeating it cannot corrupt an
//      already-corrected tree. sbx_escape() writes fixed values and the bucket
//      fill is a no-op once every slot is occupied.
//    * If the escape also elevated credentials, that has to be re-applied too,
//      because the kernel can restore them at the same time.
//
//  Interval: the spec calls for every 5-10 seconds. A probe is one syscall, so
//  the cost is negligible; the original 7 s is used.
//

#import "SKSandboxKeeper.h"
#import "SKLog.h"
#import "darksword.h"
#import "sbx.h"
#import "utils.h"
#import "SKKernelLock.h"

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

// A system-privileged location. Deliberately NOT inside our own container:
// that is writable regardless of the escape, so it would tell us nothing.
static NSString * const kProbeDir  = @"/private/var/mobile/Library/Preferences";
static NSString * const kProbeFile = @"/private/var/mobile/Library/Preferences/.sbxkit_alive";

@interface SKSandboxKeeper ()
@property (nonatomic, readwrite) BOOL running;
@property (nonatomic, readwrite) NSUInteger repairCount;
@property (nonatomic, strong) dispatch_source_t timer;
@property (nonatomic, assign) BOOL accessLostReported;
@end

@implementation SKSandboxKeeper

+ (instancetype)sharedKeeper {
    static SKSandboxKeeper *s;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[SKSandboxKeeper alloc] init]; });
    return s;
}

- (instancetype)init {
    self = [super init];
    if (self) _interval = 7.0;
    return self;
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Probe
// ─────────────────────────────────────────────────────────────────────────────

+ (BOOL)hasPrivilegedWriteAccess {
    // open() on a privileged directory is not enough — read access can survive
    // while write access is gone, which is exactly the failure mode we are
    // detecting. Create + write + remove a file instead.
    const char *path = kProbeFile.UTF8String;

    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) return NO;

    const char marker[] = "alive\n";
    ssize_t n = write(fd, marker, sizeof(marker) - 1);
    close(fd);
    unlink(path);

    return n == (ssize_t)(sizeof(marker) - 1);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Tick
// ─────────────────────────────────────────────────────────────────────────────

+ (BOOL)ensureWriteAccess {
    if ([self hasPrivilegedWriteAccess]) return YES;
    [[self sharedKeeper] tick];
    return [self hasPrivilegedWriteAccess];
}

- (BOOL)tick {
    if (!ds_is_ready()) {
        // No primitive yet; nothing we can do and nothing we should try.
        return NO;
    }

    if ([SKSandboxKeeper hasPrivilegedWriteAccess]) {
        self.accessLostReported = NO;
        return YES;
    }

    // Access was lost: the kernel re-derived the policy from the profile.
    // Re-apply only the policy edit. sbx_escape() re-reads proc/ucred/label/
    // sandbox/ext_set from the kernel itself, so a rebuilt structure is picked
    // up automatically and nothing is cached between ticks.
    if (!self.accessLostReported) {
        self.accessLostReported = YES;
        SKLog(@"keeper: privileged write access lost — re-applying sandbox policy");
        [self emit:@"写权限已丢失 —— 正在重新修改沙箱策略"];
    }

    uint64_t proc = ds_get_our_proc();
    if (proc == 0) proc = ourproc();

    // sbx_escape() reads and writes kernel memory; it must not run while a scan,
    // a decrypt or the .app ownership walk is using the primitive.
    [SKKernelLock() lock];
    int rc = sbx_escape(proc);
    [SKKernelLock() unlock];

    if (rc != 0) {
        // Keep trying on the next tick: the design accepts that the kernel will
        // keep restoring the policy, and repairing is cheap. This is a plain
        // memory write, not a re-exploit, so retrying carries no panic risk.
        SKLog(@"keeper: re-apply returned rc=%d — will retry next tick", rc);
        [self emit:[NSString stringWithFormat:@"重新修改沙箱策略失败 (rc=%d)，下次继续", rc]];
        return NO;
    }

    self.repairCount += 1;
    BOOL restored = [SKSandboxKeeper hasPrivilegedWriteAccess];
    self.accessLostReported = !restored;
    SKLog(@"keeper: re-apply ok, probe=%s (repair #%lu)",
          restored ? "restored" : "still failing", (unsigned long)self.repairCount);
    [self emit:restored
        ? [NSString stringWithFormat:@"写权限已恢复（第 %lu 次修补）", (unsigned long)self.repairCount]
        : @"已重新修改策略，但探针仍未通过，下次继续"];
    return restored;
}

- (void)emit:(NSString *)msg {
    NSLog(@"[keeper] %@", msg);
    if (self.onEvent) self.onEvent(msg);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Lifecycle
// ─────────────────────────────────────────────────────────────────────────────

- (void)start {
    if (self.running) return;
    if (!ds_is_ready()) {
        [self emit:@"not starting: kernel primitive not up"];
        return;
    }

    NSTimeInterval iv = self.interval;
    if (iv < 3.0)  iv = 3.0;
    if (iv > 60.0) iv = 60.0;

    SKLog(@"keeper: starting, probing every %.0fs", iv);

    dispatch_queue_t q = dispatch_queue_create("sbxkit.keeper", DISPATCH_QUEUE_SERIAL);
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, q);
    dispatch_source_set_timer(self.timer,
                              dispatch_time(DISPATCH_TIME_NOW, (int64_t)(iv * NSEC_PER_SEC)),
                              (uint64_t)(iv * NSEC_PER_SEC),
                              1 * NSEC_PER_SEC);

    __weak typeof(self) weakSelf = self;
    dispatch_source_set_event_handler(self.timer, ^{
        [weakSelf tick];
    });

    dispatch_resume(self.timer);
    self.running = YES;
    [self emit:[NSString stringWithFormat:@"started (every %.0fs)", iv]];
}

- (void)stop {
    if (!self.running) return;
    if (self.timer) {
        dispatch_source_cancel(self.timer);
        self.timer = nil;
    }
    self.running = NO;
    [self emit:@"stopped"];
}

@end
