//
//  JBClean.m
//  JBClean
//

#import "JBClean.h"

#import "SKLog.h"
#import "SKKernelLock.h"
#import "SKSandboxKeeper.h"

#import "darksword.h"
#import "offsets.h"
#import "apfs.h"
#import "utils.h"
#import "sbx.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

// mobile:mobile — the uid this app runs as, and therefore the owner the tree
// has to carry before unlink()/rmdir() will accept our calls.
static const uid_t kJBOwnerUID = 501;
static const gid_t kJBOwnerGID = 501;

static const int        kJBMaxDepth   = 64;
static const NSUInteger kJBMaxEntries = 400000;
// apfs_own() syncs three times per path. For a tree of any size that dominates
// the run, so the kernel write path here batches and syncs once per N paths.
static const NSUInteger kJBSyncEvery  = 200;

// JBLoc() lives in JBClean.h — main.m uses it too.

// Defined further down, next to the vnode walk it wraps.
static BOOL JBOwnThroughKernel(NSString *path, uid_t uid, gid_t gid);

// Implemented in the @implementation below, declared here because the C helpers
// above it record the pending parent restore through them.
@interface JBClean ()
+ (void)rememberParent:(NSString *)path uid:(uid_t)uid gid:(gid_t)gid;
+ (void)forgetParent;
+ (nullable NSString *)pendingRecord;
@end

// Pending-restore record: "<path>|<uid>|<gid>", written before the parent is
// chowned and removed once it is back. Survives the process dying.
static NSString * const kJBPendingParentKey = @"JBPendingParentRestore";

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Small helpers
// ─────────────────────────────────────────────────────────────────────────────

static NSString *JBModeString(mode_t m) {
    char out[11];
    if      (S_ISDIR(m))  out[0] = 'd';
    else if (S_ISLNK(m))  out[0] = 'l';
    else if (S_ISCHR(m))  out[0] = 'c';
    else if (S_ISBLK(m))  out[0] = 'b';
    else if (S_ISFIFO(m)) out[0] = 'p';
    else if (S_ISSOCK(m)) out[0] = 's';
    else                  out[0] = '-';
    static const char rwx[] = "rwx";
    for (int i = 0; i < 9; i++) out[1 + i] = (m & (1u << (8 - i))) ? rwx[i % 3] : '-';
    out[10] = '\0';
    return @(out);
}

// Run a shell command and capture its output. Used only for launchctl, where
// the exit status and the message are both worth showing. Failure is never
// fatal to the clean.
static NSString *JBRun(NSString *command) {
    FILE *fp = popen(command.UTF8String, "r");
    if (!fp) return @"(popen failed)";
    char buf[1024];
    size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
    buf[n] = '\0';
    int rc = pclose(fp);
    NSString *out = [@(buf) stringByTrimmingCharactersInSet:
                        NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (!out.length) out = [NSString stringWithFormat:@"exit=%d", WEXITSTATUS(rc)];
    return out;
}

// A root shallow enough to be dangerous ("/", "/var") is refused. Everything
// this tool exists for is at least two components deep.
static BOOL JBRootIsSafe(NSString *root) {
    if (![root isAbsolutePath]) return NO;
    return root.pathComponents.count >= 3;
}

// What a symlink points at, or nil when it is not one / cannot be read.
// readlink() does NOT follow the link — which is the whole point.
static NSString *JBLinkTarget(NSString *path) {
    char buf[4096];
    ssize_t n = readlink(path.fileSystemRepresentation, buf, sizeof(buf) - 1);
    if (n <= 0) return nil;
    buf[n] = '\0';
    return @(buf);
}

// Canonicalise a path: every component resolved, symlinks gone. Returns nil on
// failure (which is what a dangling link does).
//
// This matters more than it looks. On iOS /var IS a symlink to /private/var, so
// lstat("/var") describes the LINK (mode 0777, no useful uid) while
// open("/var") lands on /private/var. Anything that compares kernel state with
// filesystem state has to agree on WHICH object it is talking about, and the
// only way to get that right is to canonicalise first.
static NSString *JBRealPath(NSString *path) {
    char buf[4096];
    if (!realpath(path.fileSystemRepresentation, buf)) return nil;
    return @(buf);
}

// Parent directories this tool is willing to chown.
//
// The UI only ever asks for /var/jb, whose parent is /private/var. The list is
// explicit so that a future custom path — or a typo — can never make the tool
// chown something like /private/var/mobile. A directory that is already 501:501
// is also allowed: chowning it to 501:501 changes nothing.
static BOOL JBParentIsSafeToChown(NSString *realParent) {
    static NSArray<NSString *> *allowed;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        allowed = @[ @"/private/var", @"/private/preboot" ];
    });
    if ([allowed containsObject:realParent]) return YES;

    struct stat sb;
    if (stat(realParent.fileSystemRepresentation, &sb) == 0 &&
        sb.st_uid == kJBOwnerUID && sb.st_gid == kJBOwnerGID) {
        return YES;                       // already ours — a no-op
    }
    return NO;
}

// Where the pending-restore record is mirrored, outside the app container, so
// that it survives the app being deleted and reinstalled. /private/var/tmp is
// mode 1777 and is reachable once the sandbox escape is up.
static NSString * const kJBDurableRecordPath = @"/private/var/tmp/.jbclean-pending-restore";

// Is the ownership the kernel holds for `path` already the one we asked for?
//
// This is what makes the chown-then-syscall sequence safe to attempt: if the
// write did not land, we do NOT call rmdir() with a directory we do not
// actually own — we fall through to the restore instead. The window in which
// the parent is owned by mobile is therefore zero in the failure case.
static BOOL JBOwnershipIsVisible(NSString *path, uid_t uid, gid_t gid) {
    struct stat sb;
    return stat(path.fileSystemRepresentation, &sb) == 0 &&
           sb.st_uid == uid && sb.st_gid == gid;
}

// Put the parent back, retrying. A transient kernel-write failure here is the
// one outcome that must not be accepted quietly, so it gets three attempts and
// each one is verified.
static BOOL JBRestoreParent(NSString *path, uid_t uid, gid_t gid) {
    for (int attempt = 0; attempt < 3; attempt++) {
        JBOwnThroughKernel(path, uid, gid);
        if (JBOwnershipIsVisible(path, uid, gid)) return YES;
        sync();                       // only on the failure path
    }
    return NO;
}

// Remove the root entry itself.
//
// rmdir() and unlink() are both governed by the PARENT directory's write
// permission, and the parent is normally /private/var — root:wheel. So the
// parent is made ours for exactly as long as the syscall takes, then put back.
//
// Three things make that acceptable rather than reckless:
//
//   1. The parent is CANONICALISED first. /var is a symlink to /private/var, and
//      the kernel checks permission on the resolved directory. Resolving up
//      front means the object we chown, the object we record for the restore,
//      and the object the kernel checks are provably the same one.
//   2. The window contains no sync(), no logging and no allocation — a chown, a
//      visibility check, one syscall, and the restore.
//   3. The restore is recorded (twice) before the chown and retried with
//      verification after it. If it still fails, the record is deliberately
//      left behind so the next launch replays it.
//
// This is also the only correct way to remove a SYMLINK. A link is unlinked,
// never followed, and its own uid/gid is irrelevant: the parent decides. That
// is why "the link is owned by uid 0" does not matter here, and why anything
// that stats or opens the link before removing it is doing it wrong — open()
// follows the link, so a dangling link reports ENOENT and a live one hands you
// the target instead of the link.
static BOOL JBRemoveRootEntry(NSString *root, BOOL isDir, void (^say)(NSString *)) {
    // ── resolve the parent ─────────────────────────────────────────────────
    NSString *parentLink = root.stringByDeletingLastPathComponent;
    if (!parentLink.length) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.noparent"), @"?"]);
        return NO;
    }
    NSString *parent = JBRealPath(parentLink) ?: parentLink;

    struct stat psb;
    if (stat(parent.fileSystemRepresentation, &psb) != 0 || !S_ISDIR(psb.st_mode)) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.noparent"), parent]);
        return NO;
    }
    if (!JBParentIsSafeToChown(parent)) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.parent.unsafe"), parent]);
        return NO;
    }

    const uid_t oldUID = psb.st_uid;
    const gid_t oldGID = psb.st_gid;

    say([NSString stringWithFormat:JBLoc(@"jb.clean.parent"),
         parent, oldUID, oldGID, kJBOwnerUID, kJBOwnerGID]);

    // Record the intended restore BEFORE anything changes — in NSUserDefaults
    // (survives a crash) and in /private/var/tmp (survives the app being
    // deleted, so a reinstall can still put it right).
    [JBClean rememberParent:parent uid:oldUID gid:oldGID];

    // Flush BEFORE opening the window. JBOwnThroughKernel() may need a sync of
    // its own if the filesystem does not immediately report the new owner, and
    // doing this first means that sync — if it happens at all — has almost
    // nothing left to write and returns at once.
    sync();

    // ── window begins ──────────────────────────────────────────────────────
    BOOL chowned = JBOwnThroughKernel(parent, kJBOwnerUID, kJBOwnerGID);
    BOOL usable  = chowned && JBOwnershipIsVisible(parent, kJBOwnerUID, kJBOwnerGID);

    int rc = -1, savedErrno = EACCES;
    if (usable) {
        rc = isDir ? rmdir(root.fileSystemRepresentation)
                   : unlink(root.fileSystemRepresentation);
        savedErrno = errno;
    }
    // ── window ends ────────────────────────────────────────────────────────

    BOOL restored = JBRestoreParent(parent, oldUID, oldGID);
    sync();

    if (!restored) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.parent.fail"),
             [JBClean describePath:parent]]);
        // Deliberately keep the record: it is the only thing that can put this
        // right on the next launch.
    } else {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.parent.rc"), oldUID, oldGID]);
        [JBClean forgetParent];
    }

    if (!usable) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.parent.notusable"), parent]);
        return NO;
    }
    if (rc != 0) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.rmfail"), strerror(savedErrno)]);
        return NO;
    }
    return YES;
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Ownership through the kernel
// ─────────────────────────────────────────────────────────────────────────────
//
// This is the whole trick. getvnodefor() opens the path O_RDONLY (directories
// are 0755 root:wheel, so uid 501 has r-x and the open succeeds), then walks
// fp_glob -> fg_data to the vnode and v_data to the apfs_fsnode. Rewriting
// uid/gid there changes the file's owner without going through the permission
// check that would otherwise refuse us.
//
// It also means no root is needed: the kernel is doing the store on our behalf.

static BOOL JBOwnThroughKernel(NSString *path, uid_t uid, gid_t gid) {
    if (!ds_is_ready()) return NO;

    // lstat, never stat. A symlink is refused outright rather than followed:
    // open() below WOULD follow it, and rewriting the owner of whatever a link
    // points at is never what was intended. Callers that legitimately deal with
    // a symlinked path — /var is one, on iOS — canonicalise it with realpath()
    // before calling in.
    struct stat sb;
    if (lstat(path.fileSystemRepresentation, &sb) != 0) return NO;
    if (S_ISLNK(sb.st_mode)) return NO;

    [SKKernelLock() lock];

    BOOL wrote = NO;
    uint64_t vnode = getvnodefor(path.fileSystemRepresentation);
    if (vnode != (uint64_t)-1 && vnode != 0) {
        uint64_t fsnode = ds_kread64(vnode + off_vnode_v_data);
        if (fsnode) {
            // Self-validation, and the most important safety check in this file.
            //
            // We are about to store 4 bytes at fsnode+offsetof(uid) and 4 more
            // at fsnode+offsetof(gid) in KERNEL MEMORY. If off_vnode_v_data were
            // wrong for this kernel we would be scribbling into some unrelated
            // object instead. So before writing anything: the fsnode must
            // ALREADY report exactly the uid/gid that the filesystem reports
            // for this precise path. When both views agree, the vnode -> fsnode
            // link is confirmed and the store is known to land on the object we
            // think it does. When they disagree, nothing is written at all.
            if (apfs_getuid(fsnode) == (uint32_t)sb.st_uid &&
                apfs_getgid(fsnode) == (uint32_t)sb.st_gid) {
                apfs_setuid(fsnode, uid);
                apfs_setgid(fsnode, gid);
                wrote = YES;
            }
        }
    }

    [SKKernelLock() unlock];

    if (!wrote) return NO;
    if (JBOwnershipIsVisible(path, uid, gid)) return YES;

    // APFS can hold the new owner in the fsnode without the filesystem
    // reporting it yet — apfs_own() flushes for the same reason. Only done on
    // the miss path, so the common case costs no sync at all.
    sync();
    return JBOwnershipIsVisible(path, uid, gid);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Tree walk
// ─────────────────────────────────────────────────────────────────────────────

typedef struct {
    NSUInteger         entries;
    NSUInteger         dirs;
    NSUInteger         files;
    NSUInteger         others;
    NSUInteger         unreadable;   // directories opendir() refused
    unsigned long long bytes;
    int                depth;
} JBTally;

static void JBWalk(NSString *path, int depth, JBTally *tally,
                   void (^visit)(NSString *p, const struct stat *sb, int depth))
{
    if (depth > kJBMaxDepth) return;
    if (tally->entries >= kJBMaxEntries) return;

    struct stat sb;
    if (lstat(path.fileSystemRepresentation, &sb) != 0) return;

    tally->entries++;
    if (depth > tally->depth) tally->depth = depth;
    if (visit) visit(path, &sb, depth);

    if (!S_ISDIR(sb.st_mode)) {
        if (S_ISREG(sb.st_mode)) {
            tally->files++;
            tally->bytes += (unsigned long long)sb.st_size;
        } else {
            tally->others++;
        }
        return;
    }
    tally->dirs++;

    DIR *d = opendir(path.fileSystemRepresentation);
    if (!d) { tally->unreadable++; return; }

    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        @autoreleasepool {
            NSString *child = [path stringByAppendingPathComponent:@(e->d_name)];
            JBWalk(child, depth + 1, tally, visit);
        }
    }
    closedir(d);
}

// Remove every entry inside `dir`, deepest-first. Symlinks are unlinked, never
// followed. Leaves `dir` itself in place — that is handled by the caller, which
// has to make the parent writable first.
static void JBRemoveChildren(NSString *dir, NSUInteger *removed, NSUInteger *failed) {
    // opendir() FOLLOWS a symlink. Refuse to descend unless lstat says this is
    // a genuine directory, so a link planted anywhere in the tree can never
    // redirect the delete at whatever it points to.
    struct stat dsb;
    if (lstat(dir.fileSystemRepresentation, &dsb) != 0 || !S_ISDIR(dsb.st_mode)) {
        (*failed)++;
        return;
    }

    DIR *d = opendir(dir.fileSystemRepresentation);
    if (!d) { (*failed)++; return; }

    NSMutableArray<NSString *> *kids = [NSMutableArray array];
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        [kids addObject:@(e->d_name)];
    }
    closedir(d);

    for (NSString *name in kids) {
        @autoreleasepool {
            NSString *p = [dir stringByAppendingPathComponent:name];
            struct stat sb;
            if (lstat(p.fileSystemRepresentation, &sb) != 0) { (*failed)++; continue; }

            if (S_ISDIR(sb.st_mode)) {
                JBRemoveChildren(p, removed, failed);
                if (rmdir(p.fileSystemRepresentation) == 0) (*removed)++;
                else                                        (*failed)++;
            } else {
                if (unlink(p.fileSystemRepresentation) == 0) (*removed)++;
                else                                         (*failed)++;
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - JBClean
// ─────────────────────────────────────────────────────────────────────────────

@implementation JBClean

// ── /private/var: hand it to mobile, or take it back ───────────────────────
//
// While /private/var is owned by mobile, uid 501 can create and remove entries
// directly in /var through the ordinary filesystem calls — no kernel primitive
// needed for that part. It is a deliberate loosening, so it is reversible and
// the operator's intent is recorded.
//
// The record exists because of a conflict: the safety sweep in
// repairParentOwnership() treats any system directory sitting at 501:501 as the
// residue of an interrupted clean and reverts it. Without a way to say "this
// one is intentional", the sweep would silently undo this on every exploit run.
static NSString * const kJBVarOwnedByMobileKey = @"JBVarOwnedByMobile";

+ (BOOL)varIsGivenToMobile {
    return [NSUserDefaults.standardUserDefaults boolForKey:kJBVarOwnedByMobileKey];
}

+ (NSString *)giveVarToMobile:(BOOL)enable {
    NSMutableString *rep = [NSMutableString string];
    void (^say)(NSString *) = ^(NSString *line) { [rep appendFormat:@"%@\n", line]; };

    if (!ds_is_ready()) { say(JBLoc(@"jb.clean.nokernel")); return rep; }

    // Canonical path: /var is a symlink, and the kernel checks the resolved
    // directory. Working on /var here would chown the target anyway via open(),
    // but the record and the report have to name the object that actually
    // changes.
    NSString *var = @"/private/var";
    struct stat sb;
    if (stat(var.fileSystemRepresentation, &sb) != 0 || !S_ISDIR(sb.st_mode)) {
        say([NSString stringWithFormat:JBLoc(@"jb.link.absent"), var]);
        return rep;
    }

    say([NSString stringWithFormat:JBLoc(@"jb.var.before"), [self describePath:var]]);

    const uid_t wantUID = enable ? kJBOwnerUID : 0;
    const gid_t wantGID = enable ? kJBOwnerGID : 0;
    NSString *wantName = enable ? @"501:501" : @"0:0";

    if (sb.st_uid == wantUID && sb.st_gid == wantGID) {
        say([NSString stringWithFormat:JBLoc(@"jb.var.already"), wantName]);
    } else if (!JBRestoreParent(var, wantUID, wantGID)) {
        say([NSString stringWithFormat:JBLoc(@"jb.var.fail"), [self describePath:var]]);
        return rep;                       // leave the record alone
    } else {
        say([NSString stringWithFormat:JBLoc(@"jb.var.after"), [self describePath:var]]);
    }

    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    if (enable) {
        [d setBool:YES forKey:kJBVarOwnedByMobileKey];
        say(JBLoc(@"jb.var.note.on"));
    } else {
        [d removeObjectForKey:kJBVarOwnedByMobileKey];
        say(JBLoc(@"jb.var.note.off"));
    }
    [d synchronize];

    return rep;
}

// ── pending parent restore ─────────────────────────────────────────────────
//
// The record is written to two places, because each covers a different way of
// losing it:
//
//   NSUserDefaults                 survives a crash or a SIGKILL of this process
//   /private/var/tmp/.jbclean-...  also survives the app being deleted, so a
//                                  reinstall can still put the directory back
//
// /private/var/tmp is mode 1777, so writing there needs no privilege beyond the
// sandbox escape that is already up whenever this code runs.
+ (void)rememberParent:(NSString *)path uid:(uid_t)uid gid:(gid_t)gid {
    NSString *rec = [NSString stringWithFormat:@"%@|%u|%u", path, uid, gid];

    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    [d setObject:rec forKey:kJBPendingParentKey];
    [d synchronize];              // must be on disk before the chown happens

    [rec writeToFile:kJBDurableRecordPath atomically:YES
            encoding:NSUTF8StringEncoding error:NULL];
}

+ (void)forgetParent {
    NSUserDefaults *d = NSUserDefaults.standardUserDefaults;
    [d removeObjectForKey:kJBPendingParentKey];
    [d synchronize];
    [NSFileManager.defaultManager removeItemAtPath:kJBDurableRecordPath error:NULL];
}

+ (nullable NSString *)pendingRecord {
    NSString *rec = [NSUserDefaults.standardUserDefaults stringForKey:kJBPendingParentKey];
    if (rec.length) return rec;
    return [NSString stringWithContentsOfFile:kJBDurableRecordPath
                                     encoding:NSUTF8StringEncoding error:NULL];
}

+ (NSString *)repairParentOwnership {
    if (!ds_is_ready()) return nil;

    NSMutableArray<NSString *> *lines = [NSMutableArray array];

    // ── (a) replay an interrupted chown ────────────────────────────────────
    NSString *rec = [self pendingRecord];
    if (rec.length) {
        NSArray<NSString *> *parts = [rec componentsSeparatedByString:@"|"];
        if (parts.count != 3 || !parts[0].length) {
            [self forgetParent];
        } else {
            NSString *path = parts[0];
            // NSString has no -unsignedIntValue (that is NSNumber); longLongValue
            // is the widest conversion it declares, and uid_t/gid_t are 32-bit.
            uid_t uid = (uid_t)[parts[1] longLongValue];
            gid_t gid = (gid_t)[parts[2] longLongValue];

            if (JBOwnershipIsVisible(path, uid, gid)) {
                [self forgetParent];              // already back — nothing to do
            } else if (JBRestoreParent(path, uid, gid)) {
                sync();
                [self forgetParent];
                [lines addObject:[NSString stringWithFormat:JBLoc(@"jb.repair.ok"),
                                  path, uid, gid]];
            } else {
                [lines addObject:[NSString stringWithFormat:JBLoc(@"jb.repair.fail"),
                                  [self describePath:path], uid, gid]];
            }
        }
    }

    // ── (b) unconditional sweep of the system directories we are willing to
    //        touch ──────────────────────────────────────────────────────────
    // Belt and braces. A directory sitting at exactly 501:501 is our signature,
    // so restoring it can only ever undo something this tool did — it cannot
    // "fix" a state it did not cause. This is what covers the case where the
    // record itself was lost.
    for (NSString *sys in @[ @"/private/var", @"/private/preboot" ]) {
        // Respect a deliberate hand-over. Without this the sweep would treat the
        // operator's own change as residue and undo it on every exploit run.
        if ([sys isEqualToString:@"/private/var"] && [self varIsGivenToMobile]) continue;

        struct stat sb;
        if (stat(sys.fileSystemRepresentation, &sb) != 0) continue;
        if (sb.st_uid != kJBOwnerUID || sb.st_gid != kJBOwnerGID) continue;

        if (JBRestoreParent(sys, 0, 0)) {
            sync();
            [lines addObject:[NSString stringWithFormat:JBLoc(@"jb.repair.sweep"), sys]];
        } else {
            [lines addObject:[NSString stringWithFormat:JBLoc(@"jb.repair.fail"),
                              [self describePath:sys], 0, 0]];
        }
    }

    return lines.count ? [lines componentsJoinedByString:@"\n"] : nil;
}

+ (NSString *)describePath:(NSString *)path {
    struct stat sb;
    if (lstat(path.fileSystemRepresentation, &sb) != 0) {
        return [NSString stringWithFormat:@"%@  (%s)", path, strerror(errno)];
    }
    return [NSString stringWithFormat:@"%u:%-5u %@ %11lld  %@",
            sb.st_uid, sb.st_gid, JBModeString(sb.st_mode),
            (long long)sb.st_size, path];
}

+ (NSString *)describeLink:(NSString *)path {
    struct stat sb;
    if (lstat(path.fileSystemRepresentation, &sb) != 0) {
        return [NSString stringWithFormat:@"%@  (%s)", path, strerror(errno)];
    }
    NSString *target = JBLinkTarget(path) ?: @"?";
    struct stat tsb;
    NSString *tail;
    if (stat(path.fileSystemRepresentation, &tsb) != 0) {
        tail = JBLoc(@"jb.diag.linkdangling_short");
    } else {
        tail = [NSString stringWithFormat:@"-> %@", target];
    }
    return [NSString stringWithFormat:@"%u:%-5u %@ %11lld  %@  %@",
            sb.st_uid, sb.st_gid, JBModeString(sb.st_mode),
            (long long)sb.st_size, path, tail];
}


// ── diagnose ───────────────────────────────────────────────────────────────
+ (NSString *)diagnose:(NSString *)root {
    NSMutableString *rep = [NSMutableString string];
    void (^say)(NSString *) = ^(NSString *line) {
        [rep appendFormat:@"%@\n", line];
        SKLog(@"[jbclean] %@", line);
    };

    struct stat sb;
    if (lstat(root.fileSystemRepresentation, &sb) != 0) {
        say([NSString stringWithFormat:JBLoc(@"jb.diag.absent"), root]);
        return rep;
    }

    say([NSString stringWithFormat:JBLoc(@"jb.diag.target"), root]);
    say([NSString stringWithFormat:JBLoc(@"jb.diag.stat"), [self describePath:root]]);

    // A symlink is surveyed as a symlink. Descending into it would describe —
    // and later delete — whatever it points at, which is not what the operator
    // asked for and may not even be the same filesystem.
    if (S_ISLNK(sb.st_mode)) {
        NSString *target = JBLinkTarget(root);
        say(JBLoc(@"jb.diag.link"));
        say([NSString stringWithFormat:JBLoc(@"jb.diag.linkto"), target ?: @"?"]);

        struct stat tsb;
        if (!target.length) {
            say(JBLoc(@"jb.diag.linkbad"));
        } else if (stat(root.fileSystemRepresentation, &tsb) != 0) {
            say([NSString stringWithFormat:JBLoc(@"jb.diag.linkdangling"), strerror(errno)]);
        } else {
            say([NSString stringWithFormat:JBLoc(@"jb.diag.linkexists"),
                 JBModeString(tsb.st_mode),
                 JBLoc(S_ISDIR(tsb.st_mode) ? @"jb.kind.dir" : @"jb.kind.file"),
                 (long long)tsb.st_size]);
        }
        // Unlinking a link depends only on the parent. Say so, because the
        // link's own owner (often root) is a red herring.
        say([NSString stringWithFormat:JBLoc(@"jb.diag.linkparent"),
             [self describePath:root.stringByDeletingLastPathComponent]]);
        return rep;
    }

    JBTally tally;
    memset(&tally, 0, sizeof(tally));

    // Ownership histogram, keyed "uid:gid".
    NSMutableDictionary<NSString *, NSNumber *> *owners = [NSMutableDictionary dictionary];

    JBWalk(root, 0, &tally, ^(NSString *p, const struct stat *s, int depth) {
        NSString *key = [NSString stringWithFormat:@"%u:%-5u", s->st_uid, s->st_gid];
        owners[key] = @(owners[key].unsignedIntegerValue + 1);
    });

    say([NSString stringWithFormat:JBLoc(@"jb.diag.tree"),
         (unsigned long)tally.entries, (unsigned long)tally.dirs,
         (unsigned long)tally.files, (unsigned long)tally.others,
         tally.bytes, tally.depth]);

    if (tally.unreadable) {
        say([NSString stringWithFormat:JBLoc(@"jb.diag.unreadable"), (unsigned long)tally.unreadable]);
    }

    say(JBLoc(@"jb.diag.owners"));
    NSArray<NSString *> *sortedKeys =
        [owners.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSString *a, NSString *b) {
            return [owners[b] compare:owners[a]];
        }];
    for (NSString *key in sortedKeys) {
        say([NSString stringWithFormat:JBLoc(@"jb.diag.ownerline"), key, owners[key].unsignedLongValue]);
    }

    say(JBLoc(@"jb.diag.launchd"));
    NSString *ldDir = [root stringByAppendingPathComponent:@"Library/LaunchDaemons"];
    NSArray<NSString *> *plists = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:ldDir error:NULL];
    NSUInteger shown = 0;
    for (NSString *name in plists) {
        if (![name hasSuffix:@".plist"]) continue;
        say([NSString stringWithFormat:JBLoc(@"jb.diag.plist"),
             [self describePath:[ldDir stringByAppendingPathComponent:name]]]);
        shown++;
    }
    if (!shown) say(JBLoc(@"jb.diag.launchd.none"));

    return rep;
}

// ── clean ──────────────────────────────────────────────────────────────────
+ (NSString *)clean:(NSString *)root progress:(JBProgressBlock)progress {
    NSMutableString *rep = [NSMutableString string];
    void (^say)(NSString *) = ^(NSString *line) {
        [rep appendFormat:@"%@\n", line];
        SKLog(@"[jbclean] %@", line);
        if (progress) progress(line);
    };

    if (!JBRootIsSafe(root)) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.badroot"), root]);
        return rep;
    }
    if (!ds_is_ready()) {
        say(JBLoc(@"jb.clean.nokernel"));
        return rep;
    }

    struct stat sb;
    if (lstat(root.fileSystemRepresentation, &sb) != 0) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.nothing"), root]);
        return rep;
    }

    say([NSString stringWithFormat:JBLoc(@"jb.diag.target"), root]);
    say([NSString stringWithFormat:JBLoc(@"jb.diag.stat"), [self describePath:root]]);

    // ── symlink: this is a link removal, not a tree removal ────────────────
    // Never walk it, never follow it. The link is unlinked and nothing else is
    // touched — in particular whatever it points at is left exactly as it is.
    if (S_ISLNK(sb.st_mode)) {
        NSString *target = JBLinkTarget(root);
        say([NSString stringWithFormat:JBLoc(@"jb.clean.islink"), target ?: @"?"]);
        JBRemoveRootEntry(root, NO, say);

        say(JBLoc(@"jb.clean.step5"));
        if (lstat(root.fileSystemRepresentation, &sb) != 0) {
            say([NSString stringWithFormat:JBLoc(@"jb.clean.gone"), root]);
        } else {
            say([NSString stringWithFormat:JBLoc(@"jb.clean.left"), root]);
        }
        return rep;
    }

    // ── (1) stop the launchd job ───────────────────────────────────────────
    // Done first: a job with KeepAlive would otherwise be re-launched while we
    // are deleting underneath it. Best-effort — a uid-501 process cannot unload
    // a job that root loaded into the system domain, and the output says so
    // rather than pretending it worked.
    say(JBLoc(@"jb.clean.step1"));
    NSString *ldDir = [root stringByAppendingPathComponent:@"Library/LaunchDaemons"];
    NSFileManager *fm = NSFileManager.defaultManager;
    for (NSString *name in ([fm contentsOfDirectoryAtPath:ldDir error:NULL] ?: @[])) {
        if (![name hasSuffix:@".plist"]) continue;
        NSString *plist = [ldDir stringByAppendingPathComponent:name];
        NSString *label = [name stringByDeletingPathExtension];
        say([NSString stringWithFormat:JBLoc(@"jb.clean.unload"), plist,
             JBRun([NSString stringWithFormat:@"launchctl unload '%@' 2>&1", plist])]);
        say([NSString stringWithFormat:JBLoc(@"jb.clean.remove"), label,
             JBRun([NSString stringWithFormat:@"launchctl remove '%@' 2>&1", label])]);
    }

    // ── (2) take ownership of every directory ──────────────────────────────
    // Only directories strictly need this: to unlink a file, or rmdir a
    // subdirectory, the kernel checks write permission on the PARENT. Once
    // every directory along the path is ours, the tree can be removed
    // regardless of who owns the files inside. Files are attempted too, but a
    // failure there is recorded and ignored — a 0600 root-owned file cannot be
    // opened by uid 501, and it does not need to be.
    say([NSString stringWithFormat:JBLoc(@"jb.clean.step2"), kJBOwnerUID, kJBOwnerGID]);

    __block NSUInteger ownedOK = 0, ownedFail = 0, checked = 0, linksSkipped = 0;
    JBTally tally;
    memset(&tally, 0, sizeof(tally));

    JBWalk(root, 0, &tally, ^(NSString *p, const struct stat *s, int depth) {
        // A symlink is never followed and never chowned. Removing it depends on
        // the parent directory, not on the link, and open()ing it would hand us
        // the target instead. The parent gets taken care of in step 4.
        if (S_ISLNK(s->st_mode)) { linksSkipped++; return; }
        if (s->st_uid == kJBOwnerUID && s->st_gid == kJBOwnerGID) { ownedOK++; return; }
        if (JBOwnThroughKernel(p, kJBOwnerUID, kJBOwnerGID)) ownedOK++;
        else                                                 ownedFail++;
        if (++checked % kJBSyncEvery == 0) sync();
    });
    sync();

    say([NSString stringWithFormat:JBLoc(@"jb.clean.ownresult"),
         (unsigned long)ownedOK, (unsigned long)ownedFail]);
    if (linksSkipped) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.skiplinks"),
             (unsigned long)linksSkipped]);
    }

    // ── (3) delete the contents, deepest-first ─────────────────────────────
    say(JBLoc(@"jb.clean.step3"));
    NSUInteger removed = 0, failed = 0;
    JBRemoveChildren(root, &removed, &failed);
    say([NSString stringWithFormat:JBLoc(@"jb.clean.delresult"),
         (unsigned long)removed, (unsigned long)failed]);

    // ── (4) remove the root itself ─────────────────────────────────────────
    // rmdir(root) is governed by root's PARENT, which is normally /private/var
    // and normally root:wheel. JBRemoveRootEntry() makes it ours for exactly as
    // long as the syscall takes, records the restore beforehand, and puts it
    // back with verification. See the notes on that function — this is the only
    // place in the tool that touches anything outside the tree being removed.
    if (lstat(root.fileSystemRepresentation, &sb) == 0) {
        say(JBLoc(@"jb.clean.step4"));
        JBRemoveRootEntry(root, S_ISDIR(sb.st_mode) ? YES : NO, say);
    }

    // ── (5) verify ─────────────────────────────────────────────────────────
    say(JBLoc(@"jb.clean.step5"));
    if (lstat(root.fileSystemRepresentation, &sb) != 0) {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.gone"), root]);
        say(JBLoc(@"jb.clean.reboot"));
    } else {
        say([NSString stringWithFormat:JBLoc(@"jb.clean.left"), root]);
        NSArray<NSString *> *left = [fm contentsOfDirectoryAtPath:root error:NULL];
        if (left.count) {
            say([NSString stringWithFormat:JBLoc(@"jb.clean.leftlist"),
                 [left componentsJoinedByString:@", "]]);
        }
    }

    return rep;
}

// ── selfCheck ──────────────────────────────────────────────────────────────
+ (NSString *)selfCheck {
    NSMutableString *rep = [NSMutableString string];
    void (^say)(NSString *) = ^(NSString *line) {
        [rep appendFormat:@"%@\n", line];
    };

    say(JBLoc(@"jb.self.header"));
    say([NSString stringWithFormat:JBLoc(@"jb.self.ids"),
         getuid(), geteuid(), getgid(), getegid()]);
    say([NSString stringWithFormat:JBLoc(@"jb.self.kernel"),
         ds_is_ready() ? JBLoc(@"jb.self.yes") : JBLoc(@"jb.self.no"),
         (unsigned long long)ds_get_kernel_base(),
         (unsigned long long)ds_get_kernel_slide()]);
    say([NSString stringWithFormat:JBLoc(@"jb.self.sandbox"),
         [SKSandboxKeeper hasPrivilegedWriteAccess] ? JBLoc(@"jb.self.yes") : JBLoc(@"jb.self.no")]);

    // The system directories this tool is willing to touch, reported by their
    // CANONICAL path. /var is a symlink to /private/var, so showing /var here
    // would describe the link rather than the directory the kernel actually
    // checks — and the directory the permission repair acts on.
    say(JBLoc(@"jb.self.sysdirs"));
    for (NSString *sys in @[ @"/private/var", @"/private/preboot" ]) {
        struct stat ssb;
        if (stat(sys.fileSystemRepresentation, &ssb) != 0) {
            say([NSString stringWithFormat:@"  %@  (%s)", sys, strerror(errno)]);
            continue;
        }
        BOOL ours = (ssb.st_uid == kJBOwnerUID && ssb.st_gid == kJBOwnerGID);
        NSString *tag = @"";
        if (ours) {
            // Two very different reasons for the same state, and they call for
            // opposite responses — say which one this is.
            tag = ([sys isEqualToString:@"/private/var"] && [self varIsGivenToMobile])
                    ? JBLoc(@"jb.self.sysdirs.given")
                    : JBLoc(@"jb.self.sysdirs.ours");
        }
        say([NSString stringWithFormat:@"  %@%@", [self describePath:sys], tag]);
    }

    NSString *pend = [self pendingRecord];
    if (pend.length) {
        say([NSString stringWithFormat:JBLoc(@"jb.self.pending"), pend]);
    }

    // The root-level symlinks, reported by lstat so the LINK's own owner is
    // shown. Their ownership is cosmetic — path resolution never consults it —
    // but it is what a file manager displays, so it belongs on this page rather
    // than in a surprise.
    say(JBLoc(@"jb.self.syslinks"));
    for (NSString *lnk in @[ @"/var", @"/tmp", @"/etc", @"/private" ]) {
        struct stat lsb;
        if (lstat(lnk.fileSystemRepresentation, &lsb) != 0) continue;
        say([NSString stringWithFormat:@"  %@",
             S_ISLNK(lsb.st_mode) ? [self describeLink:lnk] : [self describePath:lnk]]);
    }

    say(@"");
    return rep;
}

@end
