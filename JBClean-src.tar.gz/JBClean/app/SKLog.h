//
//  SKLog.h
//  Blade
//
//  Append-only diagnostic log written to the app's Documents/sk.log.
//  Documents is reachable from the host over SSH (the app is not sandboxed
//  away from us here), so a device test can be diagnosed without the user
//  having to relay anything by hand.
//

#ifndef SKLog_h
#define SKLog_h

#import <Foundation/Foundation.h>

// printf-style, newline terminated, flushed after every line.
void SKLog(NSString *fmt, ...) NS_FORMAT_FUNCTION(1, 2);

// Absolute path of the log file (handy to print at startup).
NSString *SKLogPath(void);

#endif /* SKLog_h */
