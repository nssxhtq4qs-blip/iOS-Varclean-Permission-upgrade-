# JBClean

一个用 **Objective-C + UIKit** 写的 iOS 工具，用来查看并删除越狱工具在
`/var/jb` 留下的持久化目录树。它的存在是为了替代原来那套 **Swift UI** ——
Swift 必须用 Xcode/macOS 编译，而这里没有 Mac；Obj-C 可以直接用
clang + ld64 对着 iPhoneOS SDK 编译出 arm64 的 IPA。

## 产物

    dist/JBClean-arm64.ipa      417 KB, sha256 1459d25c10da9b35...
    bundle id                   com.jbclean.app
    可执行文件                  jbclean
    架构                        arm64, cpusubtype 0 (CPU_SUBTYPE_ARM64_ALL)
    chained fixups              pointer_format 6 (DYLD_CHAINED_PTR_64_OFFSET)

## 编译

    ./build.sh                 # arm64  <- 默认，也是唯一在设备上验证过的
    ./build.sh --arch arm64e   # arm64e，不要用，见下

`build.sh` 是 Blade 那套脚本的副本，改了三处默认值（`SRC` / `OUTNAME` /
`APP`）和 `DIST`，并去掉了不再需要的 `ProcessListViewController.m`。
`src/app/*.m` 是自动收集的，新增文件不用改脚本。

工具链沿用已经验证过的那套：

* `/opt/theos/toolchain/linux/iphone/bin/clang-11`
* `/opt/ld64-956/bin/ld`（真正的 Apple ld64-956.6，不是 theos 自带的 ld64-609）
* `/opt/theos/sdks/iPhoneOS16.5.sdk`

## 架构：必须用 arm64，不是 arm64e

这一条是用一次闪退换来的，写在这里免得再犯。

设备是 A16 / iOS 17.5，所以直觉上应该出 arm64e。**但 arm64e 的包在这台设备上
打开就黑屏闪退**，而 arm64 的包能跑。arm64 在 arm64e 设备上向后兼容，功能不受
影响 —— 这个应用的其它部分（Blade）从 2024-10-07 22:37 起就一直是 arm64 出货的：

    Blade2 / Blade3 / Blade4      21:54 - 22:26    arm64e   闪退
    Blade5 ... Blade13            22:37 - 23:17    arm64    能跑

第一版 JBClean 用了 `build.sh` 的默认值 `ARCH="arm64e"`，于是原样复现了那个闪退。
现在默认值已经改成 `arm64`，并在脚本里注明了原因。

两套 ABI 在二进制里的区别是可以直接看出来的：

    arm64e   cpusubtype 0x80000002   __TEXT,__auth_stubs + __DATA_CONST,__auth_got
                                     pointer_format 12
    arm64    cpusubtype 0x00000000   __TEXT,__stubs + __DATA_CONST,__got
                                     pointer_format 6

构建脚本对两者都做断言，所以选错架构会在构建时就暴露，不会留到设备上。

## 界面

终端风格，等宽字体，无 emoji，不强制配色（跟随系统深浅色），所有文案都走
`Localizable.strings`（en / zh-Hans / zh-Hant / ja / ko 五种语言齐全）。

```
██╗██████╗  ██████╗██╗     ███████╗ █████╗ ███╗   ██╗
██║██╔══██╗██╔════╝██║     ██╔════╝██╔══██╗████╗  ██║
██║██████╔╝██║     ██║     █████╗  ███████║██╔██╗ ██║
██║██╔══██╗██║     ██║     ██╔══╝  ██╔══██║██║╚██╗██║
╚█████╔╝██████╔╝╚██████╗███████╗███████╗██║  ██║██║ ╚████║
 ╚════╝ ╚═════╝  ╚═════╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝

{!} 内核读写未初始化
{!} 运行 exploit
    {!} 诊断 /var/jb
    {!} 清除 /var/jb
    {!} 文件管理器
    {!} 系统自检
    {!} 试验性提权（可能 panic）
    ------------------------------
    （输出区，可滚动、可复制）
```

五项操作：

| 操作 | 作用 |
|---|---|
| 诊断 /var/jb | 只读。列出存在性、属主、规模、深度、属主分布、`Library/LaunchDaemons` 里的 plist |
| 清除 /var/jb | 真正的清理，五步，见下 |
| 文件管理器 | 复用 Blade 的文件浏览器，从 `/var` 起步 |
| 系统自检 | uid/gid、内核原语、沙盒写权限、`/var` 属性，以及关于 root 的结论 |
| 试验性提权 | 调 `sbx_rootify()` 往自己的 ucred 写 uid 0。**预计失败，可能 panic**，有二次确认 |

## 清除是怎么做到的

关键在于：**不需要 root**。

`/var/jb` 里的每一项都是进程还在 root 时创建的，所以属主是 `root:wheel`。
删除一个目录项由**父目录**的写权限决定，`chown` 本身又是特权操作，所以
uid 501 的进程怎么试都失败。这两道检查都在文件系统里，不在沙盒里 ——
逃逸沙盒也解决不了。

真正有效的是 FilzaJailedDS 那套做法：用内核读写原语直接改写
**APFS fsnode 里的 uid/gid 字段**。`apfs_fsnode` 位于普通的可写 zone，
这个写是能落地的（`proc_ro`/`ucred` 则受页表保护，写不进去）。

`JBClean.m` 里的 `JBOwnThroughKernel()`：

    open(path, O_RDONLY)        // 目录是 0755 root:wheel，501 有 r-x，能打开
      -> fileproc -> fp_glob -> fg_data        = vnode
      -> vnode + off_vnode_v_data              = apfs_fsnode
      -> 改写 uid / gid

删除顺序（`+[JBClean clean:progress:]`）：

1. **卸载 launchd 任务** —— `launchctl unload <plist>` + `launchctl remove <label>`。
   尽力而为：uid 501 动不了 root 加载到系统域的任务，输出里会如实写出来。
2. **通过内核改写属主为 501:501** —— 递归整棵树。严格来说只有**目录**必须改：
   要 unlink 一个文件，或者 rmdir 一个子目录，内核只看父目录的写权限。
   一旦路径上每个目录都归我们，树就能删掉，不管里面的文件归谁。
   文件也一并尝试，失败只记录不阻断（打不开的 0600 root 文件不需要改）。
   `apfs_own()` 每个路径 sync 三次，那对大树太慢，所以这里自己按每 200 个
   路径 sync 一次。
3. **自底向上删除** —— symlink 直接 unlink，绝不跟随。
4. **删除根目录本身** —— `rmdir(/var/jb)` 由它的父目录 `/var` 决定，
   而 `/var` 是 root:wheel。所以临时把 `/var` 改成 501，rmdir，**然后恢复**。
   恢复即使在 rmdir 失败时也会执行，并且会 stat 校验恢复结果，
   没恢复成功会显式警告。
5. **校验** —— 还在就把残留列出来，而不是假报成功。

安全阀：`JBRootIsSafe()` 拒绝层级少于 3 段的路径，所以 `/` 和 `/var` 不可能被误删。

## `/var/jb` 是符号链接的情况

设备上实际情况是：**`/var/jb` 是一个符号链接**，它指向的地方已经被清空，
只剩下链接本身，属主 uid 0。

这看起来更麻烦，其实更简单 —— 但前提是**不能跟随链接**。

删除一个符号链接，内核只看**父目录的写权限**。链接自己的 uid/gid
**完全无关紧要**（`lchown` 设的那个值不参与删除判定）。所以 uid 0 是个红鲱鱼。

真正的坑在实现侧，我的第一版就有这个 bug：

* `open()` **会跟随符号链接**。悬空链接 → `ENOENT`，`getvnodefor()` 直接失败。
* `stat()` 跟随，`lstat()` 不跟随 —— 判断类型必须用 `lstat`。
* **`opendir()` 会跟随符号链接。** 如果直接对 `/var/jb` 调 `opendir()`，
  在链接有效的情况下会去操作**目标目录里的内容**，而那不是操作者要求的，
  甚至可能不在同一个文件系统上。

修法两处：

    JBRemoveChildren()   顶部加 lstat + S_ISDIR 守卫，不是真目录就直接拒绝下降
    clean()              lstat() 判定是链接就立即转入单次 unlink 分支，
                         完全跳过 step 1-3（不 unload、不扫描、不递归）

链接分支只做一件事：保存父目录属主 → 把父目录临时改成 501 → `unlink(/var/jb)`
→ 恢复父目录属主 → 校验恢复结果。**链接指向的地方一个字节都不动**，
报告里也会明确写出来。

诊断页对链接会额外显示：指向哪里、目标是否存在（悬空与否）、目标类型和大小、
以及父目录的属主 —— 让操作者自己确认这个链接确实该删。

注意 iOS 上 `/var` 本身就是指向 `/private/var` 的符号链接，所以
`/var/jb` 实际是 `/private/var/jb`；`stat("/var")` 会解析到 `/private/var`，
chown 与 unlink 的路径解析是一致的。

## 关于 Filza 里看到的那份属性

设备上 Filza 的 Get Info 显示：

    名称     jb
    所有者   root
    组       wheel
    权限     rwxr-xr-x   (0755)
    修改     2026-05-08 23:41:19

这份面板确认了最关键的一点：**uid 501 对它的 w 位是空的**，而 `/var` 同样是
`root:wheel` 0755 —— 所以 `rmdir(/var/jb)` 也过不去。这就是 Filza 自己
（以及任何普通进程）删不掉它的原因。

但它对上一条「这是符号链接」的说法是**矛盾**的：符号链接的 `lstat` 模式是
`lrwxrwxrwx` (0777)，而且 Filza 通常会额外显示一行「链接目标 →」。

两种解释都成立：

* Filza 在 Get Info 里**跟随**了链接，面板显示的是**目标**的属性；
* 或者它本来就是目录，不是链接。

这个差别对操作有影响（链接只需要 unlink 一次，目录要清空再 rmdir），所以
**不能靠猜**。`JBClean` 用 `lstat()` 判定，两种走法都已经实现：

    S_ISLNK  ->  单次 unlink，绝不跟随，目标一个字节不动
    S_ISDIR  ->  接管属主 -> 自底向上删除 -> 临时 chown 父目录 -> rmdir -> 还原
    其它     ->  单次 unlink

诊断页会把结论直接打出来（含指向哪里、目标是否存在、父目录属主），
所以装上以后先跑诊断就能定论。

## 中断恢复

`JBRemoveRootEntry()` 会临时把根目录的父目录（通常是 `/var`）改成 501:501。
如果进程恰好在这几毫秒里被杀，`/var` 就会停在 501:501。所以：

* 改之前先把**要还原成的 uid:gid** 写进 `NSUserDefaults`（`JBPendingParentRestore`），
  并 `synchronize` 落盘；
* 还原成功且校验通过后才清除该记录；
* **每次 exploit 成功后自动重放**这条记录（`+[JBClean repairParentOwnership]`），
  并且只还原到记录里那个精确的 uid:gid —— 它不可能去"修"它没弄坏的东西。

## 安全审计：会不会把系统搞坏

### 全部会改动系统状态的地方

一共只有 **3 类**，全部逐条列出：

| # | 操作 | 作用范围 | 可恢复性 |
|---|---|---|---|
| 1 | 经内核改写 fsnode 的 uid/gid | 递归 `/var/jb` 及其子项 | 无关紧要 —— 这些正是要删掉的东西 |
| 2 | 经内核改写 fsnode 的 uid/gid | **只读的父目录**（`/private/var`） | 见下，这是唯一的系统级改动 |
| 3 | `unlink` / `rmdir` | `/var/jb` 及其子项 + `/private/var/tmp` 里自己写的记录文件 | 目标本来就是垃圾 |

没有别的地方碰内核或系统文件。`FSEvent`、`sysctl`、`nvram`、`launchd` 注册表
一概不碰；唯一的外部进程调用是 `launchctl unload/remove`（只读式，失败无害）。

### 2 号操作是整个审计的核心

要 `rmdir(/var/jb)` 必须对它的父目录有写权限，而父目录是 `root:wheel`。
所以那个目录会被**短暂**改成 `501:501`，然后立刻改回。

防御有四层：

**第一层：窗口里什么都不做。** 顺序严格是

    sync()                    <- 预先刷盘，放在窗口外
    ── 窗口开始 ──
    chown 父目录 -> 501
    确认改动已生效（stat）
    rmdir / unlink
    ── 窗口结束 ──
    改回原属主（最多重试 3 次，每次都验证）
    sync()

窗口内**没有 sync、没有日志、没有内存分配**。之前的版本在窗口里放了一次
`sync()` —— 那可能耗时几十毫秒，是把风险窗口放大了一个数量级，已经删掉。

**第二层：改不动就不动。** chown 之后立刻 `stat` 确认；确认不到就**直接跳到还原**，
连 `rmdir` 都不尝试。这种情况下窗口长度为 0，而且报告会明说
「无法取得属主，因此没有尝试删除；系统状态未做任何改动」。

**第三层：写之前先自我验证。** 这是防内核写错地址的关键。

    if (apfs_getuid(fsnode) == lstat(path).st_uid &&
        apfs_getgid(fsnode) == lstat(path).st_gid) {
        才写入
    }

我们要往内核内存 `fsnode+offsetof(uid)` 写 4 个字节。如果
`off_vnode_v_data` 对这个内核是错的，就会写到别的对象上。所以**先读**：
fsnode 里的 uid/gid 必须和文件系统对这个路径报告的完全一致 —— 两边吻合，
才证明 vnode→fsnode 这条链是通的、要写的确实是那个对象。不吻合就一个字节都不写。

同时 `lstat` 判定符号链接直接拒绝（`open()` 会跟随链接，否则就会去改链接**指向**
的东西）。`/var` 这种本身是链接的路径，由调用方先用 `realpath()` 规范化后再传进来。

**第四层：两道记录 + 重启后重放。**

* 改之前把「要还原成什么」写进 `NSUserDefaults`（进程被杀也能留下）
* 同时写到 `/private/var/tmp/.jbclean-pending-restore`（**App 被删掉重装也还在**）
* 还原成功且验证通过后才清除记录
* 每次 exploit 成功后自动重放记录
* 另外还有一次**无条件清扫**：`/private/var` 和 `/private/preboot` 只要恰好是
  `501:501` 就恢复成 `root:wheel`。这个判据是「只可能是我干的」，所以它**不可能
  去修它没弄坏的东西**

**父目录白名单**：只允许 `/private/var` 和 `/private/preboot`，加上「本来就是
501:501」的目录（改成 501:501 等于没改）。所以即使有人把目标路径改成
`/private/var/mobile/...`，也会被拒绝而不是把 `/private/var/mobile` 改掉。

### 如果最坏的情况还是发生了

我把它说明白：**假如**进程恰好在窗口里被杀、`NSUserDefaults` 和记录文件都丢了、
App 又被删了 —— `/private/var` 会停在 `501:501`（权限位仍是 `0755`）。

后果是什么：

* 系统**照常启动、照常运行**。iOS 没有任何地方要求 `/private/var` 必须是 root 所有。
* mobile 因此获得了直接在 `/private/var` 下增删目录项的能力 —— 这是一个**权限异常**，
  不是系统损坏。

修复也不难：重新装上本工具、跑 exploit，启动时的无条件清扫就会把它改回 `root:wheel`。
自检页会把 `/private/var` 和 `/private/preboot` 的属主直接列出来，
是 `501:501` 的话会标红提示。

所以诚实的结论是：**有风险，但风险的形状是「一个目录属主不对」，不是「系统损坏」；
而且有四层自动恢复。** 不能承诺「零风险」——任何要动系统目录属主的做法都做不到
—— 能承诺的是：窗口最小、失败就回退、事后能自动修好，并且有地方能看到状态。

## `/var` 是符号链接，`/private/var` 才是目录

清除 `/var/jb` 之后有人会去看 `/var` 的属主，发现是 `0:80`（root:admin）而不是
`root:wheel`，以为是工具改坏了。**不是。** 设备上的日志是决定性证据：

    [jbclean] 属性: 0:0     lrwxr-xr-x          36  /var/jb
    [jbclean] 链接自己的属主无关紧要，由父目录决定 -> 0:80    lrwxr-xr-x    11  /var
    [jbclean] 父目录 /private/var 原属主 0:0，临时改为 501:501
    [jbclean] 父目录属主已恢复为 0:0

第一行 `0:80` 来自**只读的诊断**，它在清理之前 34 秒执行；清理那一步只动
`/private/var`，并且恢复成 `0:0` 是验证过的。Blade 的历史日志（同一天更早）
也只对 `.../BlockGraver.app` 做过 `apfsown`，从未碰过 `/var`。

**符号链接的属主不参与访问控制。** 这是 POSIX 明确规定的：路径解析遇到符号链接时
读取其内容然后继续，从不检查链接自身的权限位。Darwin 同样如此。所以：

* `/var` 的属主是什么，对任何操作都没有影响；
* 真正生效的是它指向的 `/private/var`，那是 `0:0 0755`，正确；
* 而且设备**本来就是带着 `0:80` 正常开机的** —— 这本身就证明了它不会造成重启循环。

界面上提供了 `把 /var 链接属主改为 0:0` 一项（可选、有确认、纯外观修复）：

* `getvnodefor()` 用 `open(O_RDONLY)`，**会跟随链接**，所以只能拿到目标；
* 这里改用 **`O_SYMLINK` (0x200000)** 让内核把链接自己交回来，之后的
  `fd -> fileproc -> fp_glob -> vnode` 走法与 `getvnodefor()` 完全相同；
* 写入前的自校验在这里作用更大：链接和目标的属主通常**不同**，
  所以「fsnode 与 lstat 一致」正好证明拿到的是链接的 fsnode 而不是目标的；
* 校验用的是 `lstat`（不跟随），写入后也用 `lstat` 复查。

## 把 /private/var 交给 mobile（可撤销）

两个菜单项：

    {!} 把 /private/var 交给 mobile (501:501)
    {!} 把 /private/var 还给 root (0:0)

交出之后，uid 501 可以在 `/var` 下**用普通文件系统调用**直接新建/删除条目 ——
用 Filza 或本应用的文件管理器都行，**不需要内核原语**。代价是一次真实的权限放宽。

### 与自动清扫的冲突

`repairParentOwnership()` 里有一条无条件清扫规则：系统目录只要是 `501:501`
就当作「上次清理被中断留下的残渣」改回 `root:wheel`。这条规则的存在是为了兜底，
但它会**在每次运行 exploit 时把这次有意的交出悄悄撤销**。

所以加了意图标记 `NSUserDefaults[@"JBVarOwnedByMobile"]`：

* 菜单交出时置位 → 清扫跳过 `/private/var`
* 菜单收回时清除 → 清扫重新保护它
* 自检页会区分两种 501:501：`<-- 有意交给 mobile` 和 `<-- 上次清理留下的残渣`

### 范围要说清楚

改的是 `/private/var` **这一个目录**。它带来的是「能在 `/var` 下直接增删条目」，
不是「能改 `/var` 下的一切」。更深的地方各有各的属主：

    /private/var          <- 这次改的
    /private/var/mobile      已经是 501:501
    /private/var/containers  已经是 501:501
    /private/var/db          仍然是 root
    /private/var/root        仍然是 root

要动 `db`、`root` 这类目录，需要对**那一个目录**做同样的操作。仓库里
`SKAppOwn.m` 已有针对 `.app` / Data 容器的版本，需要的话可以推广成任意路径。

## 校验记录

    ABI                 OK  arm64, cpusubtype=0x00000000
    pointer format      OK  [6, 6]
    chained fixups      OK  3595 pointers / 3595 rebases / 293 imports,
                            每条链都按声明的 stride 走通
    ABI 对照            Blade13.ipa 里的二进制是 cpusubtype=0 fmt=[6,6]
                        __got/__stubs —— 与本包逐项一致
    未定义符号          只剩系统框架 + libgrabkernel2 的 _grab_kernelcache
                            （TWOLEVEL 命名空间，运行时绑定，正常）
    关键符号            sbx_rootify / sbx_escape / apfs_own / getvnodefor /
                        ds_kwritezoneelement / kernelcache_present / dlkcache /
                        offsets_init / SKOwnTree / SKEnsureWriteAccess  全部 present
    JBClean 方法         clean:progress: / diagnose: / describePath: /
                        selfCheck / tryRoot / rememberParent:uid:gid: /
                        forgetParent / pendingRecord / repairParentOwnership
    新增安全辅助        JBRealPath / JBParentIsSafeToChown /
                        JBOwnershipIsVisible / JBRestoreParent
    文案                代码引用的 112 个键在 5 种语言里全部存在；
                        格式符与英文逐一比对一致
    打包 dylib          libgrabkernel2 arm64e [12,12] / libxpf arm64e [12,12]

## 关于「能不能提权到 root」

**那个 Swift 工具的 root 路径是假的。**

`src/kexploit/pe/ppl_physmap.h` 整个文件就是一个桩：

    static inline int ppl_physmap_run(void) { return -1; }

`stage1_root()` 第 46 行调用它，拿到 -1 就直接返回失败，永远走不到
"STAGE 1 SUCCESS"。而 roothunter（号称"1000+ 方法引擎"）的 `rh_hunt()`
在 bridging header 里被 import 了，**在任何地方都没有被调用过**。

真正存在的原语是 `ds_kwritezoneelement()` → `early_kwrite32bytes()` →
`setsockopt(ICMPV6, ICMP6_FILTER)`，也就是 DarkSword 的 ICMPv6 越界写。
它是对内核**虚拟地址**的直接写。往 ucred 上写会撞上 PPL 保护——这正是
Blade 的 `sbx_rootify()` 写好之后调用被撤掉的原因。

所以：**它不可能把 uid 提到 0。** 而这个工具不需要 root 也能完成清理，
因为改 APFS 属主走的是内核原语，不经过权限检查。

## 目录

    build.sh                    构建脚本
    add_strings.py              往 5 个 Localizable.strings 追加文案并校验格式符
    src/main.m                  UIKit 界面
    src/app/JBClean.h/.m        诊断 / 清理 / 自检 / 提权
    src/app/SKLog.*             日志（Documents/sk.log）
    src/app/SKDiag.*            崩溃与 panic 日志收集
    src/app/SKAppOwn.*          容器内 .app / Data 的属主修复（供文件管理器写入）
    src/app/SKSandboxKeeper.*   周期性重放沙盒策略
    src/kexploit/               DarkSword 链（与 Blade 逐字节相同）
