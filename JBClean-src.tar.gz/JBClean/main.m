//
//  main.m
//  JBClean
//
//  A UIKit (Objective-C) replacement for the Swift UI of the jailbreak tool
//  that planted /var/jb on this device. No Swift, no Xcode, no macOS — it is
//  built with clang + ld64 against the iPhoneOS SDK.
//
//  Layout
//    banner
//    {!} state line
//    {!} run exploit          (gated on a parsed kernelcache)
//    ---- once ready ----
//    {!} survey /var/jb       read-only report
//    {!} remove /var/jb       the actual clean
//    {!} file manager         browse the filesystem
//    {!} self check           ids, kernel primitive, sandbox, ownership
//    {!} experimental root    guarded, expected to fail on arm64e
//    --------------------
//    output text view
//
//  Terminal styling: monospaced, no emoji, no forced colour scheme, and every
//  string goes through Localizable.strings so it follows the system language.
//

#import <UIKit/UIKit.h>

#import "Exploit.h"
#import "FileManager.h"
#import "JBClean.h"
#import "SKLoc.h"
#import "SKLog.h"
#import "SKKernelLock.h"
#import "SKSandboxKeeper.h"
#import "sbx.h"
#import "darksword.h"
#import "offsets.h"

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Palette
// ─────────────────────────────────────────────────────────────────────────────

static UIColor *TuiText(void)   { return UIColor.labelColor; }
static UIColor *TuiDim(void)    { return UIColor.secondaryLabelColor; }
static UIColor *TuiGreen(void)  { return UIColor.systemGreenColor; }
static UIColor *TuiRed(void)    { return UIColor.systemRedColor; }
static UIColor *TuiOrange(void) { return UIColor.systemOrangeColor; }

static NSString *JBBanner(void) {
    return @"     ██╗██████╗  ██████╗██╗     ███████╗ █████╗ ███╗   ██╗\n"
            "     ██║██╔══██╗██╔════╝██║     ██╔════╝██╔══██╗████╗  ██║\n"
            "     ██║██████╔╝██║     ██║     █████╗  ███████║██╔██╗ ██║\n"
            "██   ██║██╔══██╗██║     ██║     ██╔══╝  ██╔══██║██║╚██╗██║\n"
            "╚█████╔╝██████╔╝╚██████╗███████╗███████╗██║  ██║██║ ╚████║\n"
            " ╚════╝ ╚═════╝  ╚═════╝╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝";
}

static NSArray<NSString *> *SpinFrames(void) {
    return @[ @"|", @"/", @"—", @"\\" ];
}

static NSString *ProgressBar(int filled, int total) {
    NSMutableString *s = [NSMutableString string];
    for (int i = 0; i < total; i++) [s appendString:(i < filled ? @"█" : @"░")];
    return s;
}

// sbx_escape() reports why it failed through sbx_setlogcallback(), and nothing
// was ever registering one — so the single most useful diagnostic in the whole
// toolchain (the errno of its final write test, plus the ucred/label/sandbox/
// ext_set addresses it resolved) went to the device console and vanished.
// Route it into the same log file the rest of the app writes.
static void SKBxLog(const char *message) {
    if (message && message[0]) SKLog(@"[sbx] %s", message);
}

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Tappable TUI line
// ─────────────────────────────────────────────────────────────────────────────

@interface TuiLine : UIControl
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, copy) void (^action)(void);
- (instancetype)initWithText:(NSString *)text color:(UIColor *)color action:(void (^)(void))action;
@end

@implementation TuiLine

- (instancetype)initWithText:(NSString *)text color:(UIColor *)color action:(void (^)(void))action {
    self = [super initWithFrame:CGRectZero];
    if (self) {
        _action = [action copy];
        _label = [[UILabel alloc] initWithFrame:CGRectZero];
        _label.text = text;
        _label.font = SKMono(14, UIFontWeightMedium);
        _label.textColor = color;
        _label.numberOfLines = 1;
        [self addSubview:_label];
        if (action) {
            [self addTarget:self action:@selector(tapped) forControlEvents:UIControlEventTouchUpInside];
            [self addTarget:self action:@selector(down) forControlEvents:UIControlEventTouchDown];
            [self addTarget:self action:@selector(up) forControlEvents:
                UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
        }
    }
    return self;
}

- (void)layoutSubviews { [super layoutSubviews]; self.label.frame = self.bounds; }
- (void)tapped { if (self.enabled && self.action) self.action(); }
- (void)down   { if (self.enabled) self.label.alpha = 0.5; }
- (void)up     { self.label.alpha = self.enabled ? 1.0 : 0.35; }

- (void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];
    self.label.alpha = enabled ? 1.0 : 0.35;
}

- (void)setText:(NSString *)t { self.label.text = t; }
- (NSString *)text { return self.label.text; }

@end

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - Main view controller
// ─────────────────────────────────────────────────────────────────────────────

typedef NS_ENUM(NSInteger, JBState) { JBStateIdle, JBStateRunning, JBStateReady };

@interface MainViewController : UIViewController
@property (nonatomic, assign) JBState state;

@property (nonatomic, strong) UILabel *banner;
@property (nonatomic, strong) TuiLine *statusLine;
@property (nonatomic, strong) TuiLine *runLine;

@property (nonatomic, strong) UIView *menuBox;
@property (nonatomic, strong) NSMutableArray<TuiLine *> *menuLines;

@property (nonatomic, strong) UITextView *output;
@property (nonatomic, strong) NSMutableArray<NSString *> *outputLines;

@property (nonatomic, strong) NSTimer *spinTimer;
@property (nonatomic, assign) NSInteger spinFrame;

// Kernelcache bookkeeping. The exploit is only ever offered once a kernelcache
// is present AND parsed — ds_run() with unresolved offsets panics the kernel.
@property (nonatomic, assign) BOOL kernelcachePrefetched;
@property (nonatomic, assign) BOOL kernelcacheReady;

@property (nonatomic, assign) BOOL busy;   // a diagnose/clean run is in flight
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.outputLines = [NSMutableArray array];
    // Must be allocated before buildMenu(): messaging a nil array silently
    // drops every addObject:, which leaves the menu empty with no error at all.
    self.menuLines = [NSMutableArray array];

    // Register before anything can call sbx_escape(), including the keeper.
    sbx_setlogcallback(SKBxLog);

    // The keeper already knew all of this; it just had nowhere to say it.
    __weak typeof(self) weakSelf = self;
    [SKSandboxKeeper sharedKeeper].onEvent = ^(NSString *msg) {
        [weakSelf appendOutput:[NSString stringWithFormat:@"[keeper] %@", msg]];
    };

    [self buildBanner];
    [self buildStatus];
    [self buildMenu];
    [self buildOutput];
    [self applyState:JBStateIdle];

    // Same ordering as the tool this replaces: get the kernelcache in place
    // before anything else is offered. If it is already there it is parsed and
    // no download happens; if it is missing it is fetched, and the exploit stays
    // disarmed until it is present.
    [self prefetchKernelcache];

    // Write access does not survive being suspended: the kernel re-derives the
    // sandbox policy from the on-disk profile while we are not running. Repair
    // on the way back in rather than leaving the operator with a file they
    // cannot touch.
    [NSNotificationCenter.defaultCenter addObserver:self
                                           selector:@selector(appWillEnterForeground)
                                               name:UIApplicationWillEnterForegroundNotification
                                             object:nil];
}

// ── kernelcache ────────────────────────────────────────────────────────────
- (void)prefetchKernelcache {
    if (self.kernelcachePrefetched) return;
    self.kernelcachePrefetched = YES;
    [self appendOutput:JBLoc(@"jb.log.kc.check")];
    [self fetchKernelcacheIfNeeded];
}

- (void)fetchKernelcacheIfNeeded {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        offsets_init();                       // CPU-family offsets, no KRW needed

        if (kernelcache_present()) {
            [self appendOutput:JBLoc(@"jb.log.kc.present")];
            BOOL ok = kernelcache_parse();
            self.kernelcacheReady = ok;
            [self appendOutput:ok ? JBLoc(@"jb.log.kc.parsed") : JBLoc(@"jb.log.kc.parsefail")];
            dispatch_async(dispatch_get_main_queue(), ^{ [self applyState:self.state]; });
            return;
        }

        [self appendOutput:JBLoc(@"jb.log.kc.missing")];
        BOOL got = dlkcache();
        self.kernelcacheReady = got;
        [self appendOutput:got ? JBLoc(@"jb.log.kc.got") : JBLoc(@"jb.log.kc.getfail")];
        dispatch_async(dispatch_get_main_queue(), ^{ [self applyState:self.state]; });
    });
}

// ── construction ───────────────────────────────────────────────────────────
- (void)buildBanner {
    self.banner = [[UILabel alloc] init];
    self.banner.text = JBBanner();
    self.banner.font = SKMono(13, UIFontWeightBold);
    self.banner.textColor = TuiText();
    self.banner.numberOfLines = 6;
    self.banner.adjustsFontSizeToFitWidth = YES;
    self.banner.minimumScaleFactor = 0.35;
    self.banner.lineBreakMode = NSLineBreakByClipping;
    [self.view addSubview:self.banner];
}

- (void)buildStatus {
    self.statusLine = [[TuiLine alloc] initWithText:@"{!} " color:TuiDim() action:nil];
    [self.view addSubview:self.statusLine];

    __weak typeof(self) weakSelf = self;
    self.runLine = [[TuiLine alloc] initWithText:@"{!} " color:TuiText() action:^{
        [weakSelf startRun];
    }];
    [self.view addSubview:self.runLine];
}

- (void)buildMenu {
    self.menuBox = [[UIView alloc] init];
    self.menuBox.hidden = YES;
    [self.view addSubview:self.menuBox];

    __weak typeof(self) weakSelf = self;
    NSArray<NSArray<NSString *> *> *defs = @[
        @[ @"jb.menu.diagnose", @"diagnose", @"text"  ],
        @[ @"jb.menu.clean",    @"clean",    @"red"   ],
        @[ @"jb.menu.files",    @"files",    @"text"  ],
        @[ @"jb.menu.self",     @"self",     @"text"  ],
        @[ @"jb.menu.repair",   @"repair",   @"text"  ],
        @[ @"jb.menu.givevar",  @"givevar",  @"text"  ],
        @[ @"jb.menu.takevar",  @"takevar",  @"text"  ],
    ];
    for (NSArray<NSString *> *d in defs) {
        UIColor *col = [d[2] isEqualToString:@"red"] ? TuiRed() : TuiText();
        TuiLine *l = [[TuiLine alloc] initWithText:[NSString stringWithFormat:@"{!} %@", JBLoc(d[0])]
                                             color:col
                                            action:^{ [weakSelf menuTap:d[1]]; }];
        [self.menuBox addSubview:l];
        [self.menuLines addObject:l];
    }
}

- (void)buildOutput {
    self.output = [[UITextView alloc] init];
    self.output.backgroundColor = UIColor.clearColor;
    self.output.editable = NO;
    self.output.selectable = YES;             // so a report can be copied out
    self.output.scrollEnabled = YES;
    self.output.textContainerInset = UIEdgeInsetsZero;
    self.output.textContainer.lineFragmentPadding = 0;
    self.output.font = SKMono(11, UIFontWeightRegular);
    self.output.textColor = TuiDim();
    [self.view addSubview:self.output];
}

// ── layout ─────────────────────────────────────────────────────────────────
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w = self.view.bounds.size.width, h = self.view.bounds.size.height;
    CGFloat top = self.view.safeAreaInsets.top, bot = self.view.safeAreaInsets.bottom;
    CGFloat x = 16, cw = w - 32;

    self.banner.frame = CGRectMake(x, top + 10, cw, 92);

    CGFloat y = top + 112;
    self.statusLine.frame = CGRectMake(x, y, cw, 22); y += 24;
    self.runLine.frame    = CGRectMake(x, y, cw, 22); y += 28;

    if (!self.menuBox.hidden) {
        CGFloat menuH = self.menuLines.count * 26.0;
        self.menuBox.frame = CGRectMake(x, y, cw, menuH);
        CGFloat my = 0;
        for (TuiLine *l in self.menuLines) { l.frame = CGRectMake(0, my, cw, 24); my += 26; }
        y += menuH + 6;
    }

    CGFloat outH = h - y - bot - 12;
    if (outH < 0) outH = 0;
    self.output.frame = CGRectMake(x, y, cw, outH);
}

// ── state ──────────────────────────────────────────────────────────────────
- (void)applyState:(JBState)state {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self applyState:state]; });
        return;
    }
    self.state = state;
    BOOL running = (state == JBStateRunning);
    BOOL ready = (state == JBStateReady);

    self.menuBox.hidden = !ready;

    NSString *prefix = ready ? @"{✓}" : @"{!}";
    NSString *stateText = JBLoc(ready ? @"jb.status.ready"
                            : running ? @"jb.status.running"
                                      : @"jb.status.idle");
    NSString *suffix = ready ? [@"  " stringByAppendingString:ProgressBar(6, 6)] : @"";
    self.statusLine.text = [NSString stringWithFormat:@"%@ %@%@", prefix, stateText, suffix];
    self.statusLine.label.textColor = ready ? TuiGreen() : (running ? TuiOrange() : TuiDim());

    if (ready) {
        self.runLine.text = [NSString stringWithFormat:@"{✓} %@", JBLoc(@"jb.action.run")];
        self.runLine.label.textColor = TuiGreen();
        [self.runLine setEnabled:NO];
    } else if (running) {
        self.runLine.text = [NSString stringWithFormat:@"{!} %@ %@",
                             JBLoc(@"jb.action.run"), SpinFrames()[self.spinFrame]];
        self.runLine.label.textColor = TuiText();
        [self.runLine setEnabled:NO];
    } else {
        self.runLine.text = [NSString stringWithFormat:@"{!} %@", JBLoc(@"jb.action.run")];
        self.runLine.label.textColor = TuiText();
        [self.runLine setEnabled:YES];
    }

    [self.view setNeedsLayout];
}

// ── output ─────────────────────────────────────────────────────────────────
- (void)appendOutput:(NSString *)line {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self appendOutput:line]; });
        return;
    }
    if (!line) line = @"";
    [self.outputLines addObjectsFromArray:[line componentsSeparatedByString:@"\n"]];
    if (self.outputLines.count > 4000) {
        [self.outputLines removeObjectsInRange:NSMakeRange(0, self.outputLines.count - 4000)];
    }
    [self renderOutput];
}

- (void)clearOutput {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self clearOutput]; });
        return;
    }
    [self.outputLines removeAllObjects];
    [self renderOutput];
}

- (void)renderOutput {
    self.output.text = [self.outputLines componentsJoinedByString:@"\n"];
    if (self.output.text.length) {
        [self.output scrollRangeToVisible:NSMakeRange(self.output.text.length, 0)];
    }
}

// ── run ────────────────────────────────────────────────────────────────────
- (void)startRun {
    if (self.state != JBStateIdle) return;

    // Never run the exploit without a parsed kernelcache: ds_run() with
    // unresolved offsets is what panics the kernel. Fetching is fine; running is
    // not, until one is present.
    if (!self.kernelcacheReady) {
        [self clearOutput];
        [self appendOutput:JBLoc(@"jb.log.gate.blocked")];
        [self appendOutput:JBLoc(@"jb.log.gate.why")];
        [self appendOutput:JBLoc(@"jb.log.gate.retry")];
        [self fetchKernelcacheIfNeeded];
        return;
    }

    [self clearOutput];
    [self appendOutput:JBLoc(@"jb.log.run.start")];
    [self applyState:JBStateRunning];
    [self startSpinner];

    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_) return;

        BOOL ok = [ExploitHelper runExploitWithLog:^(NSString *line) {
            if (line.length) [self_ appendOutput:[NSString stringWithFormat:@"  %@", line]];
        }];

        if (ok) {
            [self_ appendOutput:[NSString stringWithFormat:JBLoc(@"jb.log.kbase"),
                                 (unsigned long long)ds_get_kernel_base()]];
            [self_ appendOutput:[NSString stringWithFormat:JBLoc(@"jb.log.kslide"),
                                 (unsigned long long)ds_get_kernel_slide()]];
            [self_ appendOutput:[NSString stringWithFormat:JBLoc(@"jb.log.proc"),
                                 (unsigned long long)ds_get_our_proc()]];

            // If an earlier run died between chowning a parent directory and
            // putting it back, this is where it gets undone.
            NSString *repair = [JBClean repairParentOwnership];
            if (repair.length) [self_ appendOutput:repair];

            [[SKSandboxKeeper sharedKeeper] start];

            dispatch_async(dispatch_get_main_queue(), ^{
                [self_ stopSpinner];
                [self_ applyState:JBStateReady];
                [self_ appendOutput:JBLoc(@"jb.log.run.done")];
            });
        } else {
            NSString *err = [ExploitHelper errorMessage] ?: @"";
            dispatch_async(dispatch_get_main_queue(), ^{
                [self_ appendOutput:[NSString stringWithFormat:JBLoc(@"jb.log.run.fail"), err]];
                [self_ stopSpinner];
                [self_ applyState:JBStateIdle];
            });
        }
    });
}

// ── spinner ────────────────────────────────────────────────────────────────
- (void)startSpinner {
    self.spinFrame = 0;
    __weak typeof(self) weakSelf = self;
    self.spinTimer = [NSTimer scheduledTimerWithTimeInterval:0.12 repeats:YES block:^(NSTimer *t) {
        __strong typeof(weakSelf) self_ = weakSelf;
        if (!self_ || self_.state != JBStateRunning) return;
        self_.spinFrame = (self_.spinFrame + 1) % (NSInteger)SpinFrames().count;
        self_.runLine.text = [NSString stringWithFormat:@"{!} %@ %@",
                              JBLoc(@"jb.action.run"), SpinFrames()[self_.spinFrame]];
    }];
}

- (void)stopSpinner { [self.spinTimer invalidate]; self.spinTimer = nil; }
- (void)dealloc   { [self stopSpinner]; }

// ── menu ───────────────────────────────────────────────────────────────────
- (void)menuTap:(NSString *)kind {
    if ([kind isEqualToString:@"files"]) {
        FileManagerViewController *fm = [[FileManagerViewController alloc] initWithPath:@"/var"];
        fm.title = JBLoc(@"jb.menu.files");
        [self presentInNav:fm];
        return;
    }
    if ([kind isEqualToString:@"diagnose"]) { [self runDiagnose]; return; }
    if ([kind isEqualToString:@"self"])     { [self runSelfCheck]; return; }
    if ([kind isEqualToString:@"repair"])   { [self runRepairAccess]; return; }
    if ([kind isEqualToString:@"givevar"])  { [self confirmGiveVar:YES]; return; }
    if ([kind isEqualToString:@"takevar"])  { [self confirmGiveVar:NO]; return; }
    if ([kind isEqualToString:@"clean"])    { [self confirmClean]; return; }
}

- (void)confirmGiveVar:(BOOL)give {
    UIAlertController *al = [UIAlertController
        alertControllerWithTitle:JBLoc(give ? @"jb.confirm.givevar.title"
                                            : @"jb.confirm.takevar.title")
                         message:JBLoc(give ? @"jb.confirm.givevar.body"
                                            : @"jb.confirm.takevar.body")
                  preferredStyle:UIAlertControllerStyleAlert];
    [al addAction:[UIAlertAction actionWithTitle:JBLoc(@"common.cancel")
                                           style:UIAlertActionStyleCancel handler:nil]];
    [al addAction:[UIAlertAction actionWithTitle:JBLoc(give ? @"jb.confirm.givevar.ok"
                                                            : @"jb.confirm.takevar.ok")
                                           style:(give ? UIAlertActionStyleDestructive
                                                       : UIAlertActionStyleDefault)
                                         handler:^(UIAlertAction *a) { [self runGiveVar:give]; }]];
    [self presentViewController:al animated:YES completion:nil];
}

- (void)runGiveVar:(BOOL)give {
    if (self.busy) return;
    self.busy = YES;
    [self clearOutput];
    [self appendOutput:JBLoc(give ? @"jb.log.givevar.start" : @"jb.log.takevar.start")];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *rep = [JBClean giveVarToMobile:give];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self appendOutput:rep];
            self.busy = NO;
        });
    });
}

// Both directions of the same operation, sharing one implementation.
//
//   set     -> 0:0  (root:wheel)
//   restore -> 0:80 (root:admin), the value /var carries from the factory
//
// Neither can affect anything: a symlink's owner is not consulted during path
// resolution on Darwin. They exist because the value is visible in a file
// manager, and being able to put it back matters more than the value itself.

// ── repair write access ────────────────────────────────────────────────────
//
// The sandbox policy edit is volatile: the kernel re-derives it from the
// on-disk profile and write access silently disappears. Re-running the whole
// exploit restores it, but so does re-applying just the policy edit — which is
// a plain kernel memory write with none of the panic risk. This is that, plus
// a re-assertion of the /private/var hand-over if the operator asked for one.
- (void)runRepairAccess {
    if (self.busy) return;
    self.busy = YES;
    [self clearOutput];
    [self appendOutput:JBLoc(@"jb.log.repair.start")];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSMutableString *out = [NSMutableString string];

        if (!ds_is_ready()) {
            [out appendFormat:@"%@\n", JBLoc(@"jb.repair.noprimitive")];
        } else {
            BOOL before = [SKSandboxKeeper hasPrivilegedWriteAccess];
            BOOL after  = [SKSandboxKeeper ensureWriteAccess];
            [out appendFormat:JBLoc(@"jb.repair.sandbox"),
                before ? JBLoc(@"jb.self.yes") : JBLoc(@"jb.self.no"),
                after  ? JBLoc(@"jb.self.yes") : JBLoc(@"jb.self.no")];
            [out appendString:@"\n\n"];
        }

        if ([JBClean varIsGivenToMobile]) {
            [out appendString:[JBClean giveVarToMobile:YES]];
            [out appendString:@"\n"];
        } else {
            [out appendFormat:@"%@\n\n", JBLoc(@"jb.repair.var.notgiven")];
        }

        [out appendString:[JBClean selfCheck]];

        dispatch_async(dispatch_get_main_queue(), ^{
            [self appendOutput:out];
            self.busy = NO;
        });
    });
}

- (void)appWillEnterForeground {
    // Return from the background is exactly when write access is most likely to
    // be gone — the app was suspended, so the keeper was not ticking, while the
    // kernel kept re-deriving the policy. Repair immediately instead of waiting
    // for the next tick, and say what happened.
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        if (!ds_is_ready()) {
            [self appendOutput:JBLoc(@"jb.log.fg.noprimitive")];
            return;
        }
        BOOL ok = [SKSandboxKeeper ensureWriteAccess];
        [self appendOutput:ok ? JBLoc(@"jb.log.fg.ok") : JBLoc(@"jb.log.fg.lost")];
    });
}

- (void)runDiagnose {
    if (self.busy) return;
    self.busy = YES;
    [self clearOutput];
    [self appendOutput:JBLoc(@"jb.log.diag.start")];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *rep = [JBClean diagnose:@"/var/jb"];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self appendOutput:rep];
            self.busy = NO;
        });
    });
}

- (void)runSelfCheck {
    if (self.busy) return;
    self.busy = YES;
    [self clearOutput];
    [self appendOutput:[JBClean selfCheck]];
    self.busy = NO;
}

- (void)confirmClean {
    UIAlertController *al = [UIAlertController
        alertControllerWithTitle:JBLoc(@"jb.confirm.clean.title")
                         message:JBLoc(@"jb.confirm.clean.body")
                  preferredStyle:UIAlertControllerStyleAlert];
    [al addAction:[UIAlertAction actionWithTitle:JBLoc(@"common.cancel")
                                           style:UIAlertActionStyleCancel handler:nil]];
    [al addAction:[UIAlertAction actionWithTitle:JBLoc(@"jb.confirm.clean.ok")
                                           style:UIAlertActionStyleDestructive
                                         handler:^(UIAlertAction *a) { [self runClean]; }]];
    [self presentViewController:al animated:YES completion:nil];
}

- (void)runClean {
    if (self.busy) return;
    self.busy = YES;
    [self clearOutput];
    [self appendOutput:JBLoc(@"jb.log.clean.start")];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *rep = [JBClean clean:@"/var/jb" progress:^(NSString *line) {
            [self appendOutput:line];
        }];
        dispatch_async(dispatch_get_main_queue(), ^{
            [self appendOutput:@""];
            [self appendOutput:rep.length ? JBLoc(@"jb.log.clean.end") : JBLoc(@"jb.log.clean.empty")];
            self.busy = NO;
        });
    });
}

// ── navigation ─────────────────────────────────────────────────────────────
- (void)presentInNav:(UIViewController *)root {
    root.navigationItem.leftBarButtonItem =
        [[UIBarButtonItem alloc] initWithTitle:JBLoc(@"common.close")
                                        style:UIBarButtonItemStylePlain
                                       target:self action:@selector(closeModal)];
    UINavigationController *nc = [[UINavigationController alloc] initWithRootViewController:root];
    nc.modalPresentationStyle = UIModalPresentationFullScreen;
    nc.navigationBar.tintColor = TuiText();
    [self presentViewController:nc animated:YES completion:nil];
}

- (void)closeModal { [self dismissViewControllerAnimated:YES completion:nil]; }

@end

// ─────────────────────────────────────────────────────────────────────────────
#pragma mark - App delegate
// ─────────────────────────────────────────────────────────────────────────────

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application
        didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = UIColor.systemBackgroundColor;
    self.window.rootViewController = [[MainViewController alloc] init];
    [self.window makeKeyAndVisible];

    SKLog(@"=== jbclean launched: %@ / %@ ===",
          NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"?",
          NSBundle.mainBundle.bundleIdentifier ?: @"?");
    SKLog(@"log file: %@", SKLogPath());
    return YES;
}

@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
